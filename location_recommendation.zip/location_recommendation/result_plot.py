# -*- coding: utf-8 -*-
"""
Created on Tue Dec 23 12:42:28 2014

@author: guoqing
"""

import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator, FormatStrFormatter  
from numpy import array
import os

def draw(city, select, save_path, ymax, ymin, ymajor, yminor, interval, loc):
    
    fig = plt.figure(figsize=(10,10))
    ax = fig.add_subplot(111)

    ## the data
    N = 3
    
    if city == 'la':
        if select == 'Precision':
            ucf = [0.03112, 0.02390, 0.01756]
            ppr = [0.03753, 0.02760, 0.02025]
            tpr = [0.03581, 0.02588, 0.01935]
            geo = [0.04050, 0.02955, 0.02189]
            tspr_minus = [0.04008, 0.02840, 0.02197]
            tspr_minus_kernel = [0.04238, 0.03213, 0.02412]
    
        if select == 'Recall':
            ucf = [0.03580, 0.04770, 0.07405]
            ppr = [0.04101, 0.05920, 0.08143]
            tpr = [0.03894, 0.05568, 0.07808]
            geo = [0.04224, 0.06146, 0.08754]
            tspr_minus = [0.03928, 0.06252, 0.08553]
            tspr_minus_kernel = [0.04749, 0.06679, 0.09641]
    
    if city == 'ny':
        if select == 'Precision':
            ucf = [0.03399, 0.02919, 0.02433]
            ppr = [0.03897, 0.03160, 0.02538]
            tpr = [0.03768, 0.03128, 0.02483]
            geo = [0.04136, 0.03284, 0.02653]
            tspr_minus = [0.04219, 0.03363, 0.02637]
            tspr_minus_kernel = [0.04330, 0.03432, 0.02768]
        if select == 'Recall':
            ucf = [0.03803, 0.05671, 0.09240]
            ppr = [0.04153, 0.06432, 0.09544]
            tpr = [0.04069, 0.06366, 0.09458]
            geo = [0.04410, 0.06590, 0.10120]
            tspr_minus = [0.04515, 0.06771, 0.10058]
            tspr_minus_kernel = [0.04677, 0.06923, 0.10594]
    if city == 'sf':
        if select == 'Precision':
            ucf = [0.04220, 0.03694, 0.02721]
            ppr = [0.04741, 0.03335, 0.02604]
            tpr = [0.05041, 0.03809, 0.02762]
            geo = [0.05002, 0.03773, 0.02841]
            tspr_minus = [0.05168, 0.03923, 0.02872]
            tspr_minus_kernel = [0.05460, 0.04058, 0.03123]
            
        if select == 'Recall':
            ucf = [0.04143, 0.05694, 0.08409]
            ppr = [0.04357, 0.05884, 0.08644]
            tpr = [0.04608, 0.06493, 0.09172]
            geo = [0.04641, 0.06459, 0.09422]
            tspr_minus = [0.04807, 0.06683, 0.09450]
            tspr_minus_kernel = [0.05059, 0.07066, 0.10415]


    ## necessary variables
    ind = np.arange(N)                # the x locations for the groups
    width = 0.05                   # the width of the bars

    fac = 0.5
    ind = array([0, fac, 2*fac])
    ## the bars
    rects1 = ax.bar(ind, ucf, width,
                color='b',)
    rects2 = ax.bar(ind+width, ppr, width,
                color='c',)
    rects3 = ax.bar(ind+2*width, tpr, width,
                color='m',)
    rects4 = ax.bar(ind+3*width, geo, width,
                color='y',)
    rects5 = ax.bar(ind+4*width, tspr_minus, width,
                color='r',)
    rects6 = ax.bar(ind+5*width, tspr_minus_kernel, width,
                color='purple',)

    # axes and labels
    ax.set_xlim(-4*width)
    ax.set_ylim(ymin, ymax)
    ymajorLocator = MultipleLocator(ymajor) #将y轴主刻度标签设置为0.5的倍数  
    ymajorFormatter = FormatStrFormatter('%g') #设置y轴标签文本的格式  
    yminorLocator = MultipleLocator(yminor) #将此y轴次刻度标签设置为0.1的倍数  
    #yminorLocator = MultipleLocator(interval*0.5)
    ax.yaxis.set_major_locator(ymajorLocator)  
    ax.yaxis.set_major_formatter(ymajorFormatter)  
  
    ax.yaxis.set_minor_locator(yminorLocator)

    ax.set_ylabel( select+ ' @ N', fontsize = 22)
    ax.set_xlabel( 'N', fontsize = 22)
    #ax.set_title('Scores by group and gender', verticalalignment='baseline', horizontalalignment='center')
    xTickMarks = ['5', '10', '20']
    ax.set_xticks(ind+3*width)
    xtickNames = ax.set_xticklabels(xTickMarks)
    plt.setp(xtickNames, rotation=0, fontsize=18)
    zed = [tick.label.set_fontsize(18) for tick in ax.yaxis.get_major_ticks()]
    ## add a legend
    ax.legend( (rects1[0], rects2[0], rects3[0],rects4[0],rects5[0],rects6[0]), \
            ('UCF', 'PR', 'TPR', 'GCF', 'TSLR', 'TSLRS'), loc=loc, prop={'size':20})
       
    #plt.show()
    #plt.savefig()	
    matplotlib.rcParams['figure.figsize']#图片像素
    matplotlib.rcParams['savefig.dpi']#分辨率
    plt.savefig(save_path, format = 'eps')#指定分辨率
    


def main():
    
    folder = 'gowalla_'
    city = 'sf'
    result_save_dir = r'C:\Users\I314279\GQ\data\gowalla_pictures'
    select = 'Recall'
    #select = 'Precision'
    save_path = os.path.join(result_save_dir, select +'_' + city + '.eps')
    # la pre: 0.05, recall: 0.1
    # ny pre: 0.05, recall: 0.12
    # sf pre: 0.06, recall: 0.12
    interval = 0.01
    if select == 'Recall':
        ymajor = yminor = 0.01
        if city == 'la':
            ymax = 0.1
            ymin = 0.03
        else:
            ymax = 0.11
            ymin = 0.03
    else:
        ymajor = yminor = 0.005
        if city == 'la':
            ymax = 0.045
            ymin = 0.015
        elif city == 'ny':
            ymax = 0.045
            ymin = 0.02
        else:
            ymax = 0.06
            ymin = 0.02
    
    loc = 2
    if select == 'Precision':
        loc = 1
     
    draw(city, select, save_path, ymax, ymin, ymajor, yminor, interval, loc)
      

if __name__ == '__main__':
    main()