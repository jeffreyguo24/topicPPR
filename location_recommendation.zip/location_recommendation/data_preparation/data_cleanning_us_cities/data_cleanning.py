# -*- coding: utf-8 -*-
"""
Created on Thu Nov 06 20:58:58 2014

@author: guoqing
"""

from get_NY_SF_CH_records import get_records_NY_SF_CH
from remove_noisy_usersAndlocs import *

def data_cleanning():
    read_write_dir = 'C:/Users/GuoQing/Desktop/data/foursquare_pro'
    write_file_dic = {'NY':'foursquare_pro_ny.txt', 'SF':'foursquare_pro_sf.txt',\
                        'CH':'foursquare_pro_ch.txt'}
    get_records_NY_SF_CH(read_write_dir, write_file_dic)
    
    #remove noisy users and poi (<10, <5)
    remove_noisy_user_poi(read_write_dir)
    # extract useful information which will be userd in the later steps
    get_useful_info(read_write_dir)
    print "===over==="


def main():
    '''Return three files: foursquare_pro_ny_pro.txt (NY), 
        foursquare_pro_sf_pro.txt (SF), foursquare_pro_ch_pro.txt (CH)'''
    
    data_cleanning()
    

if __name__ == '__main__':
    main()