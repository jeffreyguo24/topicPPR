0. "find_popular_city.py"
Find the popular cities

1. "get_NY_LA_SF_records.py"
In order to fix the data spasity problem, I choose 3 cities to study in which the users are most active.
These 3 cities are New York("state", because NY is a independent city in US), San fransisco("city") and Chigago("city").


2. "remove_noisy_usersAndlocs.py"
In order to tackle the data spasity problem, I remove users whose POI number is less than 10.
I remove the POIs whose interested users number is less than 10.

The following is the statistics of the dataset after data cleanning. (f)means "foursquare dataset"

	                NY(f)
Number of users	       	2473	
Number of check-ins	274710
Number of locations	4522
