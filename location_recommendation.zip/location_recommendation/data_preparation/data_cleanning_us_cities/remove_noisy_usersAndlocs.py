# -*- coding: utf-8 -*-
"""
Created on Thu Nov 06 12:08:16 2014

@author: guoqing
"""

class user:
    '''This is the user class to 
        Record the location history of her'''
        
    def __init__(self, uid = None, poi_list = []):
        self.uid = uid
        self.poi_list = []
        
    def add_poi(self, poi):
        if poi not in self.poi_list:
            self.poi_list.append(poi)
        
    def get_poi_num(self):
        return len(set(self.poi_list))
    
    def get_uid(self):
        return self.uid


class poi:
    '''This is poi/location class to
        Record the users who visited this poi'''
    
    def __init__(self, poi_id = None):
        self.poi_id = poi_id
        self.user_list = []
        
    def add_user(self, user):
        if user not in self.user_list:
            self.user_list.append(user)
    
    def get_user_num(self):
        return len(self.user_list)
        
    def get_poi(self):
        return self.poi_id
        
    
def remove_noisy_user(read_file_path, write_rm_user_file_path):
    '''This function is to remove users whose check in poi number<10'''
    
    user_obj_list = []
    #record the index of a user in user_obj_list
    user_index_dic = {}
    i = -1
    read_fp = open(read_file_path, 'r')
    line = read_fp.readline()
    while line!='':
        line_list = line.split(',')
        uid = line_list[0]
        poi = line_list[3]
        #a new user come
        if uid not in user_index_dic:
            i += 1
            #set her index in user_index_dic
            user_index_dic[uid] = i
            user_obj = user(uid)
            #add the poi
            user_obj.add_poi(poi)
            #append her to the list
            user_obj_list.append(user_obj)
        #the user is already existing
        else:
            #get her index in the list
            user_index = user_index_dic[uid]
            #add the poi to her visited poi list
            user_obj_list[user_index].add_poi(poi)
        line = read_fp.readline()
    #delete a user whose number of poi < 10
    useful_user_list = []
    for i in range(0, len(user_obj_list)):
        user_obj = user_obj_list[i]
        uid = user_obj.get_uid()
        #if the poi number of a user< 10, delete him
        if user_obj.get_poi_num() >= 10:
            #delete him in the index dictinary instead of user_obj_list
            #del user_index_dic[uid]
            useful_user_list.append(uid)
    #back to beginning of the file
    read_fp.seek(0)
    #save the result after removing noisy users
    write_fp = open(write_rm_user_file_path, 'w')
    line = read_fp.readline()
    while line!='':
        line_list = line.split(',')
        uid = line_list[0]
        # if the number of a user's poi > 10
        if uid in useful_user_list:
            new_line = uid + ',' + line_list[1]+ ','+line_list[2] +  ',' + line_list[3]
            write_fp.write(new_line)
        line = read_fp.readline()
    read_fp.close()
    write_fp.close()
    print "users", len(useful_user_list)
    return write_rm_user_file_path


def remove_noisy_poi(read_rm_user_file_path, write_rm_poi_file_path):
    '''This function is to remove poi whose checked in user number<5'''
    
    poi_obj_list = []
    #record the index of a poi in poi_obj_list
    poi_index_dic = {}
    i = -1
    read_fp = open(read_rm_user_file_path, 'r')
    line = read_fp.readline()
    while line!='':
        line_list = line.split(',')
        uid = line_list[1]
        poi_id = line_list[5]
        #a new user come
        if poi_id not in poi_index_dic:
            i += 1
            #set poi index in poi_index_dic
            poi_index_dic[poi_id] = i
            poi_obj = poi(poi_id, [])
            #add the user
            poi_obj.add_user(uid)
            #append the poi to the list
            poi_obj_list.append(poi_obj)
        #the poi is already existing
        else:
            #get the poi index in the list
            poi_index = poi_index_dic[poi_id]
            #add the poi to the list
            poi_obj_list[poi_index].add_user(uid)
        line = read_fp.readline()
    #delete a poi whose visiting users < 5
    for i in range(0, len(poi_obj_list)):
        poi_obj = poi_obj_list[i]
        poi_id = poi_obj.get_poi()
        #if  a poi whose visiting users < 5, delete it
        if poi_obj.get_user_num() < 5:
            #delete him in the index dictinary instead of user_obj_list
            del poi_index_dic[poi_id]
    #back to beginning of the file
    read_fp.seek(0)
    #save the result after removing noisy users
    write_fp = open(write_rm_poi_file_path, 'w')
    line = read_fp.readline()
    while line!='':
        line_list = line.split(',')
        poi_id = line_list[5]
        # if the number of a user's poi > 10
        if poi_id in poi_index_dic:
            write_fp.write(line)
        line = read_fp.readline()
    read_fp.close()
    write_fp.close()
    print "poi", len(poi_index_dic)
        

def remove_noisy_user_poi(read_write_dir, dataset):
    '''Remove noisy users and poi'''
    
    read_file_list = [dataset+'_pro_ny.txt', dataset+'_pro_sf.txt',\
                        dataset+'_pro_la.txt']
    # the write name of files after removing noisy users
    write_rm_user_file_list = [dataset+'_pro_ny_rm_user.txt', dataset+'_pro_sf_rm_user.txt',\
                                dataset+'_pro_la_rm_user.txt']
    # the write name of files after removing noisy poi
    write_rm_poi_file_list = [dataset+'_pro_ny_rm_poi.txt', dataset+'_pro_sf_rm_poi.txt',\
                                dataset+'_pro_la_rm_poi.txt']
    # NY, LA, SF
    for i in range(0, len(read_file_list)):
        # read file name of each city
        read_file_name = read_file_list[i]
        # write file name of each city after removing noisy users
        write_rm_user_file_name = write_rm_user_file_list[i]
        # write file name of each city after removing noisy poi
        #write_rm_poi_file_name = write_rm_poi_file_list[i]
        # read path of each city
        read_file_path = read_write_dir + '/' + read_file_name
        # write path of files after removing noisy users
        write_rm_user_file_path = read_write_dir + '/' + write_rm_user_file_name
        # write path of files after removing noisy poi
        #write_rm_poi_file_path = read_write_dir + '/' + write_rm_poi_file_name
        # firstly remove the noisy users, then remove noisy poi
        read_rm_user_file_path = remove_noisy_user(read_file_path, write_rm_user_file_path)
        #remove_noisy_poi(read_rm_user_file_path, write_rm_poi_file_path)
        print read_file_name, "over"            


def get_useful_info(read_write_dir, dataset):
    '''This function is to extract the useful infomation that will be used in later steps
        Information: uid, latitude, longitude, poi_id'''
    
    read_rm_poi_file_list = [ dataset+'_pro_ny_rm_poi.txt', dataset+'_pro_sf_rm_poi.txt', \
                                dataset+'_pro_ch_rm_poi.txt']
    write_file_list = [ dataset+'_pro_ny_pro.txt', dataset+'_pro_sf_pro.txt', \
                        dataset+'_pro_la_pro.txt']
    for i in range(0, len(read_rm_poi_file_list)):
        read_rm_poi_file_path = read_write_dir + '/' + read_rm_poi_file_list[i]
        write_path = read_write_dir + '/' + write_file_list[i]
        write_fp = open(write_path, 'w')
        read_fp = open(read_rm_poi_file_path, 'r')
        line = read_fp.readline()
        while line!='':
            line_list = line.split(',') 
            new_line = line_list[1] + ',' + line_list[2] + ',' + \
                        line_list[3] + ',' + line_list[5] + '\n'
            write_fp.write(new_line)
            line = read_fp.readline()
        read_fp.close()
        write_fp.close()
            
            
def main():
    #root = 'foursquare_pro/'
    root = 'gowalla_pro/'
    dataset = 'gowalla'
    read_write_dir = 'C:/Users/GuoQing/Desktop/data/' + root
    remove_noisy_user_poi(read_write_dir, dataset)
    #get_useful_info(read_write_dir)
    print "===over==="
    
    
if __name__ == '__main__':
    main()
    