# -*- coding: utf-8 -*-
"""
Created on Thu Nov 06 15:00 2014

This script is used to get records in NY, LA and san fransisco

@author: guoqing
"""

from math import *

def compute_geodist(lat1, lon1, lat2, lon2):
    rad_lat1 = lat1*pi/180.0
    rad_lat2 = lat2*pi/180.0
    phi = rad_lat1 - rad_lat2
    lambdaa = lon1*pi/180.0 - lon2*pi/180.0
    u = sin(phi/2.0)
    v = sin(lambdaa/2.0)
    s = 2*asin(sqrt(u * u + cos(rad_lat1) * cos(rad_lat2) * v * v))
    return s * 6378.137
    

def determine_city(lat_lon_dic, lat_lon_poi, radius):
    '''this function is to determine the city of a given lat and lon of a poi'''
    
    lat_ny = lat_lon_dic['NY'][0]; lon_ny = lat_lon_dic['NY'][1]
    lat_sf = lat_lon_dic['SF'][0]; lon_sf = lat_lon_dic['SF'][1]
    lat_la = lat_lon_dic['LA'][0]; lon_la = lat_lon_dic['LA'][1]
    
    lat_poi = lat_lon_poi[0]; lon_poi = lat_lon_poi[1]
    
    dist_ny = compute_geodist(lat_poi, lon_poi, lat_ny, lon_ny)
    if dist_ny <= 20:
        return 'ny'
        
    dist_sf = compute_geodist(lat_poi, lon_poi, lat_sf, lon_sf)
    if dist_sf <= 20:
        return 'sf'
        
    dist_la = compute_geodist(lat_poi, lon_poi, lat_la, lon_la)
    if dist_la <= 20:
        return 'la'
        
    return 'else'
    

def get_records_NY_SF_CH(read_write_dir, read_path, write_file_dic, lat_lon_dic, radius, lat_lon_line_index, split):
    
    read_fp = open(read_path, 'r')
    write_ny_path = read_write_dir + '/' + write_file_dic['NY']
    write_sf_path = read_write_dir + '/' + write_file_dic['SF']
    write_la_path = read_write_dir + '/' + write_file_dic['LA']
    write_ny_fp = open(write_ny_path, 'w')
    write_sf_fp = open(write_sf_path, 'w')
    write_la_fp = open(write_la_path, 'w')
    lat_index = lat_lon_line_index[0]; lon_index = lat_lon_line_index[1]
    line = read_fp.readline()
    while line!='':
        line = line.strip('\n')
        line_list = line.split(split)
        #print line_list
        lat_lon_poi = (float(line_list[lat_index]), float(line_list[lon_index]))
        city = determine_city(lat_lon_dic, lat_lon_poi, radius)
        new_list = [line_list[0], line_list[lat_index], line_list[lon_index], line_list[-1]]
        new_line = ','.join(new_list) + '\n'
        if city == 'ny':
            write_ny_fp.write(new_line)
        elif city == 'sf':
            write_sf_fp.write(new_line)
        elif city == 'la':
            write_la_fp.write(new_line)
        line = read_fp.readline()
    read_fp.close()
    write_ny_fp.close()
    write_sf_fp.close()
    write_la_fp.close()
    
    
def main():
    '''this script is to get checkins of selected cities'''
    
    #root = 'foursquare_pro/'
    root = 'gowalla_pro/'
    dataset = 'gowalla'
    read_write_dir = 'C:/Users/GuoQing/Desktop/data/' + root
    #read_path = read_write_dir + 'foursquare1.csv'
    read_path = read_write_dir + dataset + '.txt'
    #write_file_dic = {'NY':'foursquare_pro_ny.txt', 'SF':'foursquare_pro_sf.txt',\
     #                   'LA':'foursquare_pro_la.txt'}
    write_file_dic = {'NY':'gowalla_pro_ny.txt', 'SF':'gowalla_pro_sf.txt',\
                        'LA':'gowalla_pro_la.txt'}

    split = '\t'    
    lat_lon_line_index = (2,3)
    radius = 20
    lat_lon_city_dic = {'NY':(40.7127, -74.0059), 'SF':(37.783333, -122.416667), 'LA':(34.05, -118.25)}
    get_records_NY_SF_CH(read_write_dir, read_path, write_file_dic, lat_lon_city_dic, radius, lat_lon_line_index, split)
    
    print "=== get checkins of selected cities over==="
    
if __name__ == '__main__':
    main()
    
    
'''
sf: 37.783333, -122.416667
ny: 40.7127, -74.0059
la: 34.05, -118.25
'''

'''
read_fp = open(read_path, 'r')
    write_ny_path = read_write_dir + '/' + write_file_dic['NY']
    write_sf_path = read_write_dir + '/' + write_file_dic['SF']
    write_ch_path = read_write_dir + '/' + write_file_dic['CH']
    write_ny_fp = open(write_ny_path, 'w')
    write_sf_fp = open(write_sf_path, 'w')
    write_ch_fp = open(write_ch_path, 'w')
    line = read_fp.readline()
    while line!='':
        line_list = line.split(',')
        #print line_list
        state_ny = line_list[-2]
        # "san fransisco" appeared in "city" level
        state_sf_ch = line_list[-3]
        if state_ny == 'NY':
            write_ny_fp.write(line)
        elif state_sf_ch == 'San Francisco':
            write_sf_fp.write(line)
        elif state_sf_ch == 'Chicago':
            write_ch_fp.write(line)
        line = read_fp.readline()
    read_fp.close()
    write_ny_fp.close()
    write_sf_fp.close()
    write_ch_fp.close()
'''
