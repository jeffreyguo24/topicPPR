# -*- coding: utf-8 -*-
"""
Created on Fri Oct 24 19:33:43 2014

This script is to find popular cities 

@author: guoqing
"""

data_path = 'C:/Users/GuoQing/Desktop/data/foursquare_pro/foursquare_pro.txt'
data_fp = open(data_path, 'r')
city_num_dic = {}
state_num_dic = {}
line = data_fp.readline()
while line!='':
    line_list = line.split(',')
    state = line_list[-2]
    city = line_list[-3]
    if state not in state_num_dic:
        state_num_dic[state] = 1
    else: state_num_dic[state] += 1
    if city not in city_num_dic:
        city_num_dic[city] = 1
    else: city_num_dic[city] += 1
    line = data_fp.readline()
data_fp.close()
print sorted(state_num_dic.items(), key = lambda x:x[1], reverse = True)[0:10] 
print sorted(city_num_dic.items(), key = lambda x:x[1], reverse = True)[0:10]
