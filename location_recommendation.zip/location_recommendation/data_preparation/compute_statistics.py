# -*- coding: utf-8 -*-


def compute_statistics(read_path):
    '''this function is to compute the statisitcs'''
    
    read_fp = open(read_path, 'r')
    poi_set = set()
    user_set = set()
    ck_num = 0
    line = read_fp.readline()
    while line != '':
        ck_num += 1
        line = line.strip('\n')
        line_list = line.split(',')
        uid = line_list[0]
        poi = line_list[3]
        user_set.add(uid)
        poi_set.add(poi)
        line = read_fp.readline()
    read_fp.close()
    print "user num", len(user_set)
    print "poi num", len(poi_set)
    print "check in num", ck_num
        

def main():
    '''User_based collaborative filtering
       Return result_ucf file'''
    
    #root = 'foursquare_'
    root = 'gowalla_'
    folder = 'ny'
    city = 'ny'
    read_write_dir = 'C:/Users/GuoQing/Desktop/data/' + root + folder
    read_path = read_write_dir + '/train_temp_' + city + '.txt'
    compute_statistics(read_path)
    
    print "===" + city + " compute statistics over==="
    
    
if __name__ == '__main__':
    main()
        