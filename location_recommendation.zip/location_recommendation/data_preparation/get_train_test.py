# -*- coding: utf-8 -*-
"""
Created on Thu Mar 05 13:27:12 2015

@author: I314279
"""

from math import *

class user:
    '''This class is to desribe a user's profile and it's only 
        for gettingtrain and test set'''
    
    def __init__(self, uid = None):
        self.uid = uid
        self.poi_freq_dic = {}
        self.poi_w_dic = {}
        self.poi_list = []
        self.poi_test_list = []
        self.poi_train_list = []
    
    def get_uid(self):
        return self.uid
    
    def add_poi_to_freq_dic(self, poi_id):
        '''This function is to add a poi to poi_freq_dic'''
        
        # if poi_id is not in poi_freq_dic, is new
        if poi_id not in self.poi_freq_dic:
            self.poi_freq_dic[poi_id] = 1
        # if poi_id is already in poi_freq_dic
        else:
            self.poi_freq_dic[poi_id] += 1
        
    def get_poi_freq_dic(self):
        return self.poi_freq_dic
    
    def add_poi_to_train(self, poi_id):
        self.poi_train_list.append(poi_id)
        
    def get_poi_train_list(self):
        return self.poi_train_list
    
    def add_poi_to_list(self, poi_id):
        '''This function is to add a poi to a poi_list'''
        
        # if poi_id is not in poi_list, is new; otherwise, ignore
        if poi_id not in self.poi_list:
            self.poi_list.append(poi_id) 
    
    def get_poi_list(self):
        '''get poi list of this user'''
        
        return self.poi_list
    
    def get_poi_w_dic(self):
        '''poi_freq_dic --> poi_w_dic, w(u, l) = freq(u,l)/sum(freq(u, li)^2)'''
        
        freq_square_sum = 0.0
        poi_freq_dic = self.get_poi_freq_dic()
        # compute freq_square_sum
        for poi_id in poi_freq_dic:
            if poi_id in self.get_poi_train_list():
                freq_square = poi_freq_dic[poi_id]
                freq_square_sum += freq_square
        # transfer freq --> w
        for poi_id in poi_freq_dic:
            if poi_id in self.get_poi_train_list():
                freq = poi_freq_dic[poi_id]
                w = freq / freq_square_sum
                self.poi_w_dic[poi_id] = w
        return self.poi_w_dic


def compute_geodist(lat1, lon1, lat2, lon2):
    rad_lat1 = lat1*pi/180.0
    rad_lat2 = lat2*pi/180.0
    phi = rad_lat1 - rad_lat2
    lambdaa = lon1*pi/180.0 - lon2*pi/180.0
    u = sin(phi/2.0)
    v = sin(lambdaa/2.0)
    s = 2*asin(sqrt(u * u + cos(rad_lat1) * cos(rad_lat2) * v * v))
    return s * 6378.137
    

def trans_lat_lon_to_xy(lat_center, lon_center, poi_lat_lon):
    '''this function is to transfer the lat and lon to x and y'''
    
    poi_lat = float(poi_lat_lon.split(',')[0])
    poi_lon = float(poi_lat_lon.split(',')[1])
    
    x = compute_geodist(lat_center, lon_center, lat_center, poi_lon)
    y = compute_geodist(poi_lat, poi_lon, lat_center, poi_lon)
    
    if poi_lat>=lat_center and poi_lon>=lon_center:
        return str(x) + ',' + str(y)
    elif poi_lat>=lat_center and poi_lon<=lon_center:
        x = -x
        return str(x) + ',' + str(y)
    elif poi_lat<=lat_center and poi_lon<=lon_center:
        x = -x; y = -y
        return str(x) + ',' + str(y)
    elif poi_lat<=lat_center and poi_lon>=lon_center:
        y = -y
        return str(x) + ',' + str(y)
    
    
import random

def get_train_test_sets(read_write_dir, read_path, train_write_path, test_write_path, train_kernel_write_path, train_temp_write_path, lat_lon_city):
    
    # train file save path
    train_write_fp = open(train_write_path, 'w')
    # train temp path
    train_temp_write_fp = open(train_temp_write_path, 'w')
    # test file save path
    test_write_fp = open(test_write_path, 'w')
    # train kernel fp
    train_kernel_write_fp = open(train_kernel_write_path, 'w')
    
    # poi dictionary to store poi_id, lattitude and longitude of a poi
    poi_lat_lon_dic = {}
    # user objects list
    user_obj_list = []
    #record the index of a user in user_obj_list
    user_index_dic = {}    
    
    # get user_obj_list and poi_lat_lon_dic
    i = -1
    read_fp = open(read_path, 'r')
    line = read_fp.readline()
    while line != '':
        line = line.strip('\n')
        line_list = line.split(',')
        uid = line_list[0]; lat = line_list[1]
        lon = line_list[2]; poi_id = line_list[3]
        # save poi_id and it's lat and lon into a dictionary
        if poi_id not in poi_lat_lon_dic:
            poi_lat_lon_dic[poi_id] = lat + ',' + lon
        #a new user come
        if uid not in user_index_dic:
            i += 1
            #set her index in user_index_dic
            user_index_dic[uid] = i
            user_obj = user(uid)
            #add the poi to poi_id and poi_to_freq_dic
            user_obj.add_poi_to_list(poi_id)
            user_obj.add_poi_to_freq_dic(poi_id)
            #append her to the list
            user_obj_list.append(user_obj)
        #the user is already existing
        else:
            #get her index in the list
            user_index = user_index_dic[uid]
            #add the poi to her visited poi list
            user_obj_list[user_index].add_poi_to_list(poi_id)
            user_obj_list[user_index].add_poi_to_freq_dic(poi_id)
        line = read_fp.readline()
    read_fp.close()
    
    # get train and test sets
    for user_obj in user_obj_list:
        uid = user_obj.get_uid()
        poi_list = user_obj.get_poi_list()
        poi_num = len(poi_list)
        poi_freq_dic = user_obj.get_poi_freq_dic()
        # number of poi of train set (train: test = 4:1)
        train_num = int(poi_num * 0.80 + 0.5)
        # index_list of train index in the poi_list of a user
        train_index_list = random.sample(range(0, poi_num), train_num)
        # get the train test sets
        for i in range(0, poi_num):
            poi_id = poi_list[i]
            poi_lat_lon = poi_lat_lon_dic[poi_id]
            poi_freq = poi_freq_dic[poi_id]
            new_line = uid + ',' + poi_lat_lon + ',' + poi_id + '\n'
            if i in train_index_list:
                user_obj.add_poi_to_train(poi_id)
                for i in range(0, poi_freq):
                    train_temp_write_fp.write(new_line)
            # if i is not a train index, so it's a test index in poi_list
            else: test_write_fp.write(new_line)
    train_temp_write_fp.close()
    test_write_fp.close()
    
    
    # get the center of the city
    '''
    train_temp_read_fp = open(train_temp_write_path, 'r')
    lat_sum = 0.0; lon_sum = 0.0; check_in_num = 0
    lat_center = 0.0; lon_center = 0.0
    line = train_temp_read_fp.readline()
    while line != '':
        line = line.strip('\n')
        line_list = line.split(',')
        check_in_num += 1
        lat = float(line_list[1]); lon = float(line_list[2])
        lat_sum += lat; lon_sum += lon
        line = train_temp_read_fp.readline()
    #read_fp.close()
    lat_center = lat_sum/check_in_num
    lon_center = lon_sum/check_in_num
    print lat_center, lon_center
    print "get the certer"    
    train_temp_read_fp.close()
    '''
    lat_center = lat_lon_city[0]
    lon_center = lat_lon_city[1]
    print lat_center, lon_center
    print "get the certer"
  
    # get train kernel and train datasets
    
    for user_obj in user_obj_list:
        uid = user_obj.get_uid()
        # poi_w_dic of a user
        poi_w_dic = user_obj.get_poi_w_dic()
        # poi freq of a user
        poi_freq_dic = user_obj.get_poi_freq_dic()
        # get train and train kernel set
        poi_train_list = user_obj.get_poi_train_list()
        for poi_id in poi_train_list:
            poi_lat_lon = poi_lat_lon_dic[poi_id]
            new_line = uid + ',' + poi_lat_lon + ',' + poi_id + ',' + \
                        str(poi_w_dic[poi_id]) + '\n'
            # i is a train index of a poi in poi_list
            train_write_fp.write(new_line)
            
            poi_freq = poi_freq_dic[poi_id]
            xy = trans_lat_lon_to_xy(lat_center, lon_center, poi_lat_lon)
            new_line2 = uid + ',' + xy + ',' + poi_id + '\n'
            
            for i in range(0, poi_freq):
                train_kernel_write_fp.write(new_line2)
                
    train_write_fp.close()
    train_kernel_write_fp.close()    
    
    return (train_write_path, test_write_path)


def main():
    '''get train and test sets'''
    
    root = 'gowalla_'
    folder = 'ny'
    city = 'ny'
    dataset = '/gowalla'
    read_write_dir = 'C:/Users/GuoQing/Desktop/data/' + root + folder
    read_path = read_write_dir + dataset + '_pro_' + city + '_pro.txt'
    
    #center
    lat_lon_city_dic = {'ny':(40.7127, -74.0059), 'sf':(37.783333, -122.416667), 'la':(34.05, -118.25)}
    lat_lon_city = lat_lon_city_dic[city]
    # train file save path
    train_write_path = read_write_dir + '/train_' + city + '.txt'
    # train temp file
    train_temp_write_path = read_write_dir + '/train_temp_' + city + '.txt'
    # test file save path
    test_write_path  = read_write_dir + '/test_' + city + '.txt'
    # trai_kernel save path
    train_kernel_write_path = read_write_dir + '/train_kernel_' + city + '.txt'
    
    # prepare train and test sets
    get_train_test_sets(read_write_dir, read_path, train_write_path, test_write_path, train_kernel_write_path, train_temp_write_path, lat_lon_city)
    
    #print compute_geodist(37.7650776726, -122.414312421, 37.61640706,-122.38623619)
    
    print "===over==="
    


if __name__ == '__main__':
    main()
        

'''
average:
sf center: 37.7650776726, -122.414312421
ny center: 40.7993087088, -73.9949735331
sg center: 1.32786331508, 103.844453594

goverment:
sf: 37.783333, -122.416667
ny: 40.7127, -74.0059
la: 34.05, -118.25
'''