# -*- coding: utf-8 -*-
"""
Created on Fri Oct 24 18:04:43 2014

@author: guoqing
"""

from foursquare import Foursquare
import time
import os
#from linecache import getline

class parameter:
    def __init__(self, main_num = None, level1_num=None, read_path = None, write_dir = None, 
                 id_list = None, secret_list = None):
        self.main_num = main_num
        self.level1_num = level1_num
        self.read_path = read_path
        self.write_dir = write_dir
        self.id_list = id_list
        self.secret_list = secret_list


def data_prepocess(para_obj):
    '''This function is to completely do the data prepocess, 
       it includes several times of process'''
      
    main_num = para_obj.main_num
    file_path_read = para_obj.read_path
    file_dir_write = para_obj.write_dir
    id_list = para_obj.id_list
    secret_list = para_obj.secret_list
    level1_num = para_obj.level1_num    
    
    foursquare_list  = []
    for i in range(0, 4):
        foursquare_list.append(Foursquare(client_id = id_list[i], client_secret = secret_list[i]))
        
    level2_num = 0
    #a flag to tell if the level1 file is empry; if no number in list, empty
    line_num_list = []
    line_count = 57274
    #第十个文件特殊，它末尾要添加剩下的行
    if level1_num == 10:
        line_count = 57283
    for i in range(0, line_count):
        line_num_list.append(1)
    #if still some lines misses, continue to process
    while 1 in line_num_list:
        level2_num += 1
        line_num_list = oneTime_prepocess(foursquare_list, line_count, line_num_list, main_num, level1_num, \
                            level2_num, file_path_read, file_dir_write)
    print level1_num, "over"
    
    
def oneTime_prepocess(foursquare_list, line_count, line_num_list, main_num, level1_num, \
                            level2_num, file_path_read, file_dir_write):
    '''This function is used to get more info about a location, \
       such as categories and city'''
    
    file_path_write = file_dir_write + str(main_num) + '-' + str(level1_num) +\
                        '-' + str(level2_num) + '.txt'
    fp_write = open(file_path_write,'w')
    fp_read = open(file_path_read, 'r')
    #计数
    a = 0
    line = fp_read.readline()
    while line!='':
        a += 1
        if level1_num == 1 and a%10 == 0:
            print a
        line = line.strip('\n')
        line_to_list = line.split(',')
        #current line_num in level1 sub file
        line_num = a - 1
        #only process line of which flag is 1
        if line_num_list[line_num] == 1 and len(line_to_list) == 6:
            
            #get the lat and lng and use them to get name, types
            lat = line_to_list[2]
            lng = line_to_list[3]
            if float(lat) != 0.0 and float(lng) != 0.0:
                try:
                    #结果是一个json
                    if a%2 == 0:
                        list_result =  foursquare_list[0].venues.search\
                        (params={'ll':lat+','+lng,'limit':1,'radius':500})
                    else:
                        list_result =  foursquare_list[1].venues.search\
                        (params={'ll':lat+','+lng,'limit':1,'radius':500})
                    #save the result into a list
                    list_result_venues = list_result['venues'][0]
                    loc_id = list_result_venues['id']
                    #venue.search里面的category信息不全，要用venue(id)
                    if a%2 == 0:
                        venue_details = foursquare_list[2].venues(loc_id)
                    else:
                        venue_details = foursquare_list[3].venues(loc_id)
                    
                    category_num = len(venue_details['venue']['categories'])
                    loc_category_list = []
                    loc_category_id_list = []
                    loc_category_name_list = []
                    for i in range(0, category_num):
                        loc_category_id_list.append(venue_details['venue']['categories'][i]['id'])
                        loc_category_name_list.append(venue_details['venue']['categories'][i]['name'])
                    loc_category_id_list.extend(loc_category_name_list)
                    loc_category_list = loc_category_id_list
                except:
                    line = fp_read.readline()
                    continue
                try:
                    #"venue_details 里面的city不准"
                    loc_city = list_result_venues['location']['city']
                    loc_state = list_result_venues['location']['state']
                    loc_country = list_result_venues['location']['country']
                    #use a string to save category id
                    newLine = line + ',' + ','.join(loc_category_list) + ',' + loc_city + ',' + \
                              loc_state + ',' + loc_country + '\n'
                    fp_write.write(newLine)
                    
                except:
                    line = fp_read.readline()
                    continue
            else:
                line = fp_read.readline()
                continue
        else:
            line = fp_read.readline()
            continue
        #set the line num indexed element 1 to 0; because we have successfully processed the line
        line_num_list[line_num] = 0
        line = fp_read.readline()
    return line_num_list
    fp_read.close()
    fp_write.close()


def main():
    #修改！！
    file_path_read = 'C:/Users/GuoQing/Desktop/data/foursquare_2011/FoursquareCheckins20110101-20111231_zero_num.csv'
    file_path_write = 'C:/Users/GuoQing/Desktop/data/foursquare_2011_3.txt'
    id_list = ['42HTARZH24LD5GJTT1JJ1R0XG5FCS5JHNXKGSJB3GDBRI05L', 
               'DTVS4L10HL3MEBRBLYYYI340BGJCZE2ZHCXX2DNCKG4YF353',
               'BBPO45CITHVNB0I1PNXQYYEKY05NYS5HJ0FQDVMOTHS54UMY',
               '44XORINIEMGF42SM3NAV0VG4KPU1WNT5WIBGD32JSPFKZQJQ']
    secret_list = ['KR0QWDQ2SKOFVXOTLXENIPOWFUCWGGB3UPDDBQ3AOFIYCWSS',
                   'YQ1LAWGFXNNQPZARHDMT43V5HM3QZX5XKR3FYL1CCDUF5N4L',
                   '5KVE2TIWHPZ4YXMQVCMCFPYZJJVUQ4ZEWMBHFCBEVX3DCK1I',
                   'YFC0ATMOHSYZFBJOTFMQ5RFUUWD20PD4JCUYUDGO3IJNM5ZE']
    para_obj = parameter(main_num, file_path_read, file_path_write, id_list, secret_list)
    data_prepocess(para_obj)
    print "===over==="


if __name__ == '__main__':
    main()
  
  


