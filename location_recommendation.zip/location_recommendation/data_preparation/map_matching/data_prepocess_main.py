# -*- coding: utf-8 -*-
"""
Created on Mon Oct 27 13:42:02 2014

@author: guoqing
"""

from map_category import data_prepocess
from map_category import parameter
import threading
import os

class myThread(threading.Thread):
    def __init__(self, name, para_obj):
        threading.Thread.__init__(self)
        self.name = name
        self.para_obj = para_obj
    
    def run(self):
        print "staring ", self.name
        data_prepocess(self.para_obj)
        
        
def set_parameter(main_num, thread_num):
    '''Set parameters for each map function(data_prepocess)'''
    
    #first level sub file number
    level1_num  = thread_num + 1
    data_read_dir = 'C:/Users/GuoQing/Desktop/data/foursquare_pro/' + str(main_num) + '-sub/'
    data_write_dir = 'C:/Users/GuoQing/Desktop/data/foursquare_pro/' + str(main_num) + \
                    '-' + str(level1_num) + '-pro/'    
    if not os.path.exists(data_write_dir):
        os.makedirs(data_write_dir)
    #40 accounts --> 10 threads; every machine the path might be different ***
    account_path = 'C:/Users/GuoQing/Desktop/foursquare _accounts2.txt'
    fp_account = open(account_path, 'r')
    allAccounts = fp_account.readlines()
    fp_account.close()
    
    '''Get id and secret''' 
    id_list = [];secret_list = []; id_secret_dic = {}
    for j in range(thread_num*4, thread_num*4+4):
        #[0:-1] delete '\n' in the end
        idAndSecret = allAccounts[j].strip('\n')
        # 'id\tsecret'
        accountId = idAndSecret.split('\t')[0]
        accountSecret = idAndSecret.split('\t')[1] 
        id_secret_dic.setdefault(accountId, accountSecret)
    #save id and secret into two lists separately
    for accountId in id_secret_dic:
        id_list.append(accountId)
        secret_list.append(id_secret_dic[accountId])
    #set read and write path parameters
    read_path = data_read_dir + str(main_num) + '-' + str(level1_num) + '.txt'
    write_dir = data_write_dir
    #start and end of the lines of each sub-file   
    para_obj = parameter(main_num, level1_num, read_path, write_dir, id_list, secret_list)
    return para_obj


def multi_thread(parameter_list):
    thread_list = []
    for i in range(0, len(parameter_list)):
        name = 'thread_' + str(i)
        thread_list.append(myThread(name, parameter_list[i]))
    for j in range(0, len(thread_list)):
        thread_list[j].start()
    for j in range(0, len(thread_list)):
        thread_list[j].join()

    
def main():
    #the number of the first level sub file
    main_num = 1
    parameter_list = []
    for thread_num in range(0, 10):
        para_obj = set_parameter(main_num, thread_num)
        parameter_list.append(para_obj)
    multi_thread(parameter_list)
    print "===over==="
    
    
if __name__ == '__main__':
    main()
