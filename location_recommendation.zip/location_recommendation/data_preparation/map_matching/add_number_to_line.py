# -*- coding: utf-8 -*-
"""
Created on Thu Oct 30 12:40:24 2014

@author: guoqing
"""

import os

def add_num(data_read_path, data_write_path):
    '''This function is to add 1,2,3... to each line of the file'''
    
    data_read_fp = open(data_read_path, 'r')
    data_write_fp = open(data_write_path, 'w')
    num = 0
    line = data_read_fp.readline()
    while line!='':
        num += 1
        if num%1000 == 0:
            print num
        newLine = str(num) +',' + line
        data_write_fp.write(newLine)
        line = data_read_fp.readline()
    data_read_fp.close()
    data_write_fp.close()
    print num        
    
    
def main():
    data_read_path = 'C:/Users/GuoQing/Desktop/data/foursquare_2011/FoursquareCheckins20110101-20111231_zero.csv'
    print os.path.exists(data_read_path)
    data_write_path = 'C:/Users/GuoQing/Desktop/data/foursquare_2011/FoursquareCheckins20110101-20111231_zero_num.csv'
    print "===start==="
    add_num(data_read_path, data_write_path)
    print "===over==="
    
    
if __name__ == '__main__':
    main()