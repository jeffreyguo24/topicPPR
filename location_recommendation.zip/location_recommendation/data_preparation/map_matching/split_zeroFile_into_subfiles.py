# -*- coding: utf-8 -*-
"""
Created on Thu Oct 30 13:30:13 2014

Split the zero(original) file(2290998 lines) into 4 sub files

@author: guoqing
"""

import os

def divide(data_read_path, sub_num):
    each_sub_num = int(572749/sub_num)
    data_write_dir = 'C:/Users/GuoQing/Desktop/data/foursquare_pro/1-sub/'
    if not os.path.exists(data_write_dir):
        os.makedirs('C:/Users/GuoQing/Desktop/data/foursquare_pro/1-sub/')
    data_read_fp = open(data_read_path, 'r')
    
    line = data_read_fp.readline()
    for i in range(0, sub_num):
        print i
        sub_write_path = data_write_dir + '1-' + str(i+1) + '.txt'
        sub_write_fp = open(sub_write_path, 'w')
        for j in range(i*each_sub_num, (i+1)*each_sub_num):
            sub_write_fp.write(line)
            line = data_read_fp.readline()
        sub_write_fp.close()
    data_read_fp.close()
    

def main():
    #data_dir = 'C:/Users/GuoQing/Desktop/data/foursquare_2011/'
    data_read_dir = 'C:/Users/GuoQing/Desktop/data/foursquare_pro/'
    data_read_path = data_read_dir + '1.txt'
    sub_num = 10
    divide(data_read_path, sub_num)
    print "===over==="
    
    
if __name__ == '__main__':
    main()
