# -*- coding: utf-8 -*-

"""
Created on Thu Nov 06 12:11 2014

This script is to combine all level2 files into a single txt file

@author: guoqing
"""


import os
def combine_level2_files(read_dir, write_path):
    write_fp = open(write_path, 'a')
    level0_dir_list = ['foursquare_pro1', 'foursquare_pro2',
                       'foursquare_pro3', 'foursquare_pro4']
    for level0_dir_name in level0_dir_list:
        level0_dir = read_dir + '/' + level0_dir_name
        level1_dir_list = os.listdir(level0_dir)
        for level1_dir_name in level1_dir_list:
            level1_dir = level0_dir + '/' + level1_dir_name
            #C:/Users/GuoQing/Desktop/data/foursquare_pro/foursquare_pro4/4-9-pro
            print level1_dir
            level2_file_list = os.listdir(level1_dir)
            for level2_file_name in level2_file_list:
                level2_file_read_path = level1_dir + '/' + level2_file_name
                level2_file_read_fp = open(level2_file_read_path, 'r')
                line = level2_file_read_fp.readline()
                while line!='':
                    write_fp.write(line)
                    line = level2_file_read_fp.readline()
                level2_file_read_fp.close()
                print level2_file_name, "over"
    write_fp.close()
    

def main():
    read_dir = 'C:/Users/GuoQing/Desktop/data/foursquare_pro'
    write_path = 'C:/Users/GuoQing/Desktop/data/foursquare_pro/foursquare_pro.txt'
    combine_level2_files(read_dir, write_path)
    print "===over==="
    
if __name__ == '__main__':
    main()

