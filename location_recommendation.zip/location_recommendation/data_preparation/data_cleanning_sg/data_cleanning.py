# -*- coding: utf-8 -*-
"""
Created on Thu Nov 06 21:58:42 2014

@author: guoqing
"""

from remove_noisy_usersAndlocs import *
from format_transfer import format_transfer


def data_cleanning():
    '''data cleanning: format transfer and remove noisy users and poi'''
    
    read_write_dir = 'C:/Users/GuoQing/Desktop/data/foursquare_sg'
    format_transfer(read_write_dir)
    remove_noisy_user_poi(read_write_dir)
    
   
def main():
    '''This script is to clean the data from foursquare datasets of Singapore'''
    
    data_cleanning()
    
    
if __name__ == '__main__':
    main()