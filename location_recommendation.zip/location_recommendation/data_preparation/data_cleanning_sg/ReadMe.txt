1. "format transfer"
To make the foursquare_sg and foursquare_us_cities in the same format

2. "remove_noisy_usersAndlocs.py"
In order to tackle the data spasity problem, I remove users whose POI number is less than 10.
I remove the POIs whose interested users number is less than 5.

The following is the statistics of the dataset after data cleanning. (f)means "foursquare dataset"

	                SG(f)
Number of users	       	2025	
Number of check-ins	103111
Number of locations	5434
