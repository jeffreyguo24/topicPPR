# -*- coding: utf-8 -*-
"""
Created on Thu Nov 06 22:53:34 2014

@author: guoqing
"""

def format_transfer(read_write_dir):
    read_path = read_write_dir + '/foursquare_sg.txt'
    read_fp = open(read_path, 'r')
    write_path = read_write_dir + '/foursquare_sg_ft.txt'
    write_fp = open(write_path, 'w')
    
    line = read_fp.readline()
    while line != '':
        line_list = line.split('\t')
        uid = line_list[0][5:]
        poi_id = line_list[1][4:]
        lat_long = line_list[2]
        
        new_line = uid + ',' + lat_long + ',' + poi_id + '\n'
        write_fp.write(new_line)
        line = read_fp.readline()
    read_fp.close()
    write_fp.close()