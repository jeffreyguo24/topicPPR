# -*- coding: utf-8 -*-
"""
Created on Tue Nov 11 12:10:33 2014

This simple script is to 

@author: guoqing
"""

class user:
    ''' This class is to formulate a document for a user'''
    
    def __init__(self, uid = None):
        self.uid = uid
        self.poi_list = []
        self.home = None
        self.poi_w_dic = {}
        self.poi_lat_lon_dic = {}
        self.topic_dist_list = []
    
    def get_uid(self):
        return self.uid
        
    def add_poi_to_list(self, poi_id):
        '''This function is to add a poi into poi_list'''
        
        self.poi_list.append(poi_id)
        
    def get_poi_list(self):
        '''This function is to get a poi_list of this user'''
        
        return self.poi_list
        
    def add_poi_w_to_dic(self, poi_id, w):
        '''This function is to add a poi into poi_list'''
        
        self.poi_w_dic[poi_id] = w
        
    def get_poi_w_dic(self):
        '''This function is to get a poi_list of this user'''
        
        return self.poi_w_dic
        
    def get_w_of_poi(self, poi_id):
        '''This function is to get the w of a poi of a user'''
        
        poi_w_dic = self.get_poi_w_dic()
        if poi_id not in poi_w_dic:
            return 0.0
        return poi_w_dic[poi_id]
    
    def add_poi_lat_lon_to_dic(self, poi_id, lat, lon):
        '''This function is to get the lat and lon of each poi of this user'''
        
        if poi_id not in self.poi_lat_lon_dic:
            self.poi_lat_lon_dic[poi_id] = (lat, lon)
            
    def get_poi_lat_lon_dic(self):
        return self.poi_lat_lon_dic
        
    def set_user_home(self, lat, lon):
        '''This function is to set the home of this user'''
        
        self.home = (lat, lon)
    
    def get_user_home(self):
        return self.home
        
    def set_topic_dist_list(self, topic_dist_list):
        '''add a topic preference to topic_list of the user'''
        
        self.topic_dist_list = topic_dist_list
    
    def get_topic_dist_list(self):
        return self.topic_dist_list
    
 
class topic_poi_prob:
    '''This class is to describe a poi distribution in a topic'''
    
    def __init__(self, topic_id = None):
        self.topic_id = topic_id
        #self.topic_poi_prob_dic = {}
        self.topic_poi_prob_list = []
    
    def get_topic_id(self):
        return self.topic_id
        
    def add_poi_prob_to_list(self, poi_id, prob):
        '''This function is to add a poi and its probability of a topic'''
        
        if (poi_id, prob) not in self.topic_poi_prob_list:
            self.topic_poi_prob_list.append((poi_id, prob))
        
    def get_topic_poi_prob_list(self):
        '''This function is to get the topic_poi_prob_dic of a topic'''
        
        return self.topic_poi_prob_list


def document_prepare_for_LDA(train_path, doc_path):
    '''This function is to prepare document for each user in train set'''
    
    train_fp = open(train_path, 'r')
    user_obj_list = []
    # record the index of a user in user_obj_list
    user_index_dic = {}
    i = -1
    # get the poi and its w of each user
    line = train_fp.readline()
    while line != '':
        line = line.strip('\n')
        line_list = line.split(',')
        uid = line_list[0]
        poi_id = line_list[3]
        #a new user come
        if uid not in user_index_dic:
            i += 1
            #set her index in user_index_dic
            user_index_dic[uid] = i
            # notice "userRec"
            user_obj = user(uid)
            #add the poi to poi_w_dic of a user
            user_obj.add_poi_to_list(poi_id)
            #append her to the list
            user_obj_list.append(user_obj)
        #the user is already existing
        else:
            #get her index in the list
            user_index = user_index_dic[uid]
            #add the poi to her visited poi list
            user_obj_list[user_index].add_poi_to_list(poi_id)
        line = train_fp.readline()
    train_fp.close()
    
    # save each user's records as a document
    doc_fp = open(doc_path, 'w')
    doc_num = len(user_obj_list)
    line = str(doc_num) + '\n'
    # the first line is number of documents
    doc_fp.write(line)
    for user_obj in user_obj_list:
        user_poi_list = user_obj.get_poi_list()
        # 空格连接
        line = ' '.join(user_poi_list) + '\n'
        doc_fp.write(line)
    doc_fp.close()
    return user_obj_list


def doc_prepare_for_PR(read_write_dir, user_topic_dist_path, topic_poi_dist_path, train_path, doc_path, city):
    '''This function is to prepare data for topic pagerank 
        after running LDA in java!!!'''

    # get the topic distribution for each word
    topic_poi_path = read_write_dir + '/LDA_' + city + '/model-final.twords'
    topic_poi_fp = open(topic_poi_path, 'r')
    topic_obj_list = []
    topic_id = -1
    line = topic_poi_fp.readline()
    while line != '':
        # "Topic nth"
        if line[0] == 'T':
            topic_id += 1
            topic_obj = topic_poi_prob(topic_id)
            topic_obj_list.append(topic_obj) 
        else:
            # delete \n and \t
            line = line.strip('\n')[1:]
            line_list = line.split(' ')
            poi_id = line_list[0]
            prob = line_list[1]
            topic_obj.add_poi_prob_to_list(poi_id, prob)
        line = topic_poi_fp.readline() 
    topic_poi_fp.close()
    # save topic_poi_dist
    topic_poi_dist_fp = open(topic_poi_dist_path, 'w')
    for topic_obj in topic_obj_list:
        line_list = []
        line_list.append(str(topic_obj.get_topic_id()))
        topic_poi_prob_list = topic_obj.get_topic_poi_prob_list()
        for (poi_id, prob) in topic_poi_prob_list:
            poi_id_prob = '|'.join((poi_id, prob))
            line_list.append(poi_id_prob)
        #print line_list
        line = ','.join(line_list) + '\n'
        topic_poi_dist_fp.write(line)
    topic_poi_dist_fp.close()
    print "get topic poi distribution"
    # save user_topic_dist
    user_topic_dist_fp = open(user_topic_dist_path, 'w')
    user_obj_list = document_prepare_for_LDA(train_path, doc_path)
    user_topic_path = read_write_dir + '/LDA_' + city + '/model-final.theta'
    user_topic_fp = open(user_topic_path, 'r')
    i = 0
    line = user_topic_fp.readline()
    while line != '':
        uid = user_obj_list[i].get_uid()
        i += 1
        line_list = line.split(' ')
        new_line = uid + ',' + ','.join(line_list)
        user_topic_dist_fp.write(new_line)
        line = user_topic_fp.readline()
    user_topic_dist_fp.close()
    print "get user_topic_dist"


def get_user_home(train_path, user_home_path):
    '''This function is to get home of each user
        Home is the center of top-k check-in poi'''
        
    train_fp = open(train_path, 'r')
    user_obj_list = []
    # record the index of a user in user_obj_list
    user_index_dic = {}
    i = -1
    # get the poi and its w of each user
    line = train_fp.readline()
    while line != '':
        line = line.strip('\n')
        line_list = line.split(',')
        uid = line_list[0]
        lat = line_list[1]
        lon = line_list[2]
        poi_id = line_list[3]
        w = float(line_list[4])
        #a new user come
        if uid not in user_index_dic:
            i += 1
            # set her index in user_index_dic
            user_index_dic[uid] = i
            # notice "userRec"
            user_obj = user(uid)
            # add the poi to poi_w_dic of a user
            user_obj.add_poi_w_to_dic(poi_id, w)
            # add the poi, lat, lon 
            user_obj.add_poi_lat_lon_to_dic(poi_id, lat, lon)
            #append her to the list
            user_obj_list.append(user_obj)
        #the user is already existing
        else:
            #get her index in the list
            user_index = user_index_dic[uid]
            #add the poi to her visited poi list
            user_obj_list[user_index].add_poi_w_to_dic(poi_id, w)
            # add the poi, lat, lon 
            user_obj.add_poi_lat_lon_to_dic(poi_id, lat, lon)
        line = train_fp.readline()
    train_fp.close()
    # get the home of each user
    user_home_fp = open(user_home_path, 'w')
    top_k = 2
    for user_obj in user_obj_list:
        uid = user_obj.get_uid()
        user_poi_w_dic = user_obj.get_poi_w_dic()
        user_poi_lat_lon_dic = user_obj.get_poi_lat_lon_dic()
        top3_poi_w_list = sorted(user_poi_w_dic.items(), key = lambda x:x[1], reverse = True)[0:top_k]
        lat_average = 0.0; lon_average = 0.0        
        for poi_w in top3_poi_w_list:
            #print poi_w
            poi_id = poi_w[0]
            lat_lon_tuple = user_poi_lat_lon_dic[poi_id]
            lat_average += float(lat_lon_tuple[0])
            lon_average += float(lat_lon_tuple[1])
        lat_average = lat_average/top_k
        lon_average = lon_average/top_k
        line = uid + ',' + str(lat_average) + ',' + str(lon_average) + '\n'
        user_home_fp.write(line)
    user_home_fp.close()
    
 
def get_friend(train_path, friend_read_path, friend_city_path):
    '''This function is to get friendship of users'''
    
    # get user_obj_list
    train_fp = open(train_path, 'r')
    user_friend_dic = {}
    i = -1
    # get the poi and its w of each user
    line = train_fp.readline()
    while line != '':
        line = line.strip('\n')
        line_list = line.split(',')
        uid = line_list[0]
        #a new user come
        if uid not in user_friend_dic:
            #set her index in user_index_dic
            user_friend_dic[uid] = []
        line = train_fp.readline()
    train_fp.close()
    # get friend
    friend_read_fp = open(friend_read_path, 'r')
    friend_read_fp.readline()
    line = friend_read_fp.readline()
    while line != '':
        line = line.strip('\n')
        line_list = line.split(',')
        uid1 = line_list[0]
        uid2 = line_list[1]
        if (uid1 in user_friend_dic) and (uid2 in user_friend_dic):
            user_friend_dic[uid1].append(uid2)
            user_friend_dic[uid2].append(uid1)
        line = friend_read_fp.readline()
    friend_read_fp.close()
    # save the friend
    friend_city_fp = open(friend_city_path, 'w')
    for uid in user_friend_dic:
        friend_list = user_friend_dic[uid]
        line = uid + ',' + ','.join(friend_list) + '\n'
        friend_city_fp.write(line)
    friend_city_fp.close()
   

def get_all_poi_train_list(train_read_path):
    '''This function is to get all the poi (candidate locations)'''
    
    poi_train_list = []
    train_fp = open(train_read_path, 'r')
    line = train_fp.readline()
    while line != '':
        line_list = line.split(',')
        poi_id = line_list[-2]
        if poi_id not in poi_train_list:
            poi_train_list.append(poi_id)
        line = train_fp.readline()
    return poi_train_list


def recompute_w_for_PR(train_path, user_topic_dist_path, user_w_topic_write_path):
    '''recompute w for running PR'''
    
    # first, get the original w 
    train_fp = open(train_path, 'r')
    user_obj_list = []
    # record the index of a user in user_obj_list
    user_index_dic = {}
    i = -1
    # get the poi and its w of each user
    line = train_fp.readline()
    while line != '':
        line = line.strip('\n')
        line_list = line.split(',')
        uid = line_list[0]
        poi_id = line_list[3]
        w = line_list[4]
        # a new user come
        if uid not in user_index_dic:
            i += 1
            # set her index in user_index_dic
            user_index_dic[uid] = i
            user_obj = user(uid)
            # add the poi to poi_w_dic of a user
            user_obj.add_poi_w_to_dic(poi_id, w)
            # add the poi
            user_obj.add_poi_to_list(poi_id)
            # append her to the list
            user_obj_list.append(user_obj)
        # the user is already existing
        else:
            # get her index in the list
            user_index = user_index_dic[uid]
            # add the poi to her visited poi list
            user_obj_list[user_index].add_poi_w_to_dic(poi_id, w)
            # add the poi, lat, lon 
            user_obj_list[user_index].add_poi_to_list(poi_id)
        line = train_fp.readline()
    train_fp.close()
    # get user preference for each topic
    user_topic_dist_fp = open(user_topic_dist_path, 'r')
    line = user_topic_dist_fp.readline()
    while line != '':
        line = line.strip('\n')
        line_list = line.split(',')
        uid = line_list[0]
        # the last element is '', don't know why
        topic_dist_list = line_list[1:-1]
        user_index = user_index_dic[uid]
        user_obj = user_obj_list[user_index]
        user_obj.set_topic_dist_list(topic_dist_list)
        line = user_topic_dist_fp.readline()
    user_topic_dist_fp.close()
    ## recompute the w
    user_w_topic_write_fp = open(user_w_topic_write_path, 'w')
    for user_obj in user_obj_list:
        uid = user_obj.get_uid()
        user_poi_list = user_obj.get_poi_list()
        user_topic_dist_list = user_obj.get_topic_dist_list()
        #print user_topic_dist_list
        w_topic_sum = 0.0
        for poi_id in user_poi_list:
            w = float(user_obj.get_w_of_poi(poi_id))
            for topic_pref in user_topic_dist_list:
                topic_pref = float(topic_pref)
                w_topic_sum += (w * topic_pref)
        line_list = [uid]
        for poi_id in user_poi_list:
            poi_w_topic_list = [poi_id]
            w = float(user_obj.get_w_of_poi(poi_id))
            for topic_pref in user_topic_dist_list:
                topic_pref = float(topic_pref)
                w_topic = str(w * topic_pref/w_topic_sum)
                poi_w_topic_list.append(w_topic)
            poi_w_topic_str = '|'.join(poi_w_topic_list)
            line_list.append(poi_w_topic_str)
        line = ','.join(line_list) + '\n'
        user_w_topic_write_fp.write(line)
    
    
def main():
    
    folder = 'pro'
    read_write_dir = 'C:/Users/GuoQing/Desktop/data/foursquare_' + folder
    city = 'ny'
    train_path = read_write_dir + '/train_'+ city +'.txt'
    '''
    ## prepare documents for LDA, just use the whole dataset for training LDA
    LDA_train_path = read_write_dir + '/foursquare_pro_'+ city +'_pro.txt'
    doc_path = read_write_dir + '/LDA_'+ city +'/document.dat'
    document_prepare_for_LDA(LDA_train_path, doc_path)
    
    ## after running LDA in java!!!  
    user_topic_dist_path = read_write_dir + '/user_topic_dist_'+ city +'.txt'
    topic_poi_dist_path = read_write_dir + '/topic_poi_dist_'+ city +'.txt'
    doc_path = read_write_dir + '/LDA_'+ city +'/document.dat'
    doc_prepare_for_PR(read_write_dir, user_topic_dist_path, topic_poi_dist_path,\
                        train_path, doc_path, city)
    '''
    ## get each user's home
    user_home_path = read_write_dir + '/user_home_'+ city +'.txt'   
    get_user_home(train_path, user_home_path)
    print "get users' home"    
    
    ## get each user's friend in each city 
    #friend_read_path = read_write_dir + '/FoursquareFriendship.csv'
    #friend_city_path = read_write_dir + '/friend_ny.txt'
    #get_friend(train_path, friend_read_path, friend_city_path)
    '''
    ## recompute w for running TSPR
    user_topic_dist_path = read_write_dir + '/user_topic_dist_'+ city +'.txt'
    user_w_topic_write_path = read_write_dir + '/user_w_topic_'+ city +'.txt'
    recompute_w_for_PR(train_path, user_topic_dist_path, user_w_topic_write_path)  
    print "recompute the w"
    '''
    print "===over==="
    

if __name__ == '__main__':
    main()