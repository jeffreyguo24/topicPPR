# -*- coding: utf-8 -*-
"""
Created on Sat Nov 22 19:03:04 2014

@author: guoqing
"""

import TSPR_dist_rec
import TSPR_rec

def main():
    '''TSPR_based recommendation; Return result_tspr_city.txt file'''
    
    folder = 'ny'
    city = 'ny'
    
    # ny: -0.869604297934, -0.408191762498
    # sf: -0.859000569694, -0.360847234986
    # sg: -1.69721348306, -0.161701984461
    ws = [-0.869604297934, -0.408191762498]
    #ws = [-0.859000569694, -0.360847234986]
    #ws = [-1.69721348306, -0.161701984461]
    read_write_dir = 'C:/Users/GuoQing/Desktop/data/foursquare_' + folder
    train_read_path = read_write_dir + '/train_' + city + '.txt'
    test_read_path = read_write_dir + '/test_' + city + '.txt'
    tspr_read_path = read_write_dir + '/tspr_' + city +'.txt'
    user_topic_dist_path = read_write_dir + '/user_topic_dist_' + city + '.txt'
    result_path = read_write_dir + '/result_tspr_dist_' + city + '.txt'
    home_path = read_write_dir + '/user_home_' + city + '.txt'
    rec_list_path = read_write_dir + '/tspr_dist_rec_list_' + city + '.txt'
    TSPR_dist_rec.tspr_rec(read_write_dir, train_read_path, test_read_path, user_topic_dist_path, tspr_read_path, home_path, ws, result_path, rec_list_path)
    print "===over==="
    
    rec_list_path = read_write_dir + '/tspr_rec_list_' + city + '.txt'
    result_path = read_write_dir + '/result_tspr_' + city + '.txt'
    TSPR_rec.tspr_rec(read_write_dir, train_read_path, test_read_path, user_topic_dist_path, tspr_read_path, result_path, rec_list_path)
    print "===over==="
    
    
if __name__ == '__main__':
    main()