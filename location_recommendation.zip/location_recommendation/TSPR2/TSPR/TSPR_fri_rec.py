# -*- coding: utf-8 -*-
"""
Created on Fri Nov 14 13:15:24 2014

This script is to do recommendation based on tspr

@author: guoqing
"""


class userRec:
    '''This class is to describe a user's profile in the train set
        and it's used for implementing user-based cf'''
    
    def __init__(self, uid = None):
        self.uid = uid
        self.poi_w_dic = {}
        self.poi_test_list = []
        self.poi_rec_list = []
        self.topic_pref_list = []
        self.pr_topic_list = []
        self.other_pr_dic = {}
    
    def get_uid(self):
        return self.uid
    
    def add_poi_w_to_dic(self, poi_id, w):
        '''This function is to add a poi and its w to poi_w_dic'''
        
        if poi_id not in self.poi_w_dic:
            self.poi_w_dic[poi_id] = w
    
    def get_poi_w_dic(self):
        '''This function is to get the poi_w_dic of a user'''
        
        return self.poi_w_dic
        
    def get_w_of_poi(self, poi_id):
        '''This function is to get the w of a poi of a user'''
        
        poi_w_dic = self.get_poi_w_dic()
        if poi_id not in poi_w_dic:
            return 0.0
        return poi_w_dic[poi_id]
        
    def add_poi_to_test_list(self, poi_id):
        '''This function is to add a poi to a user's poi_test_list'''
        
        if poi_id not in self.poi_test_list:
            self.poi_test_list.append(poi_id)
    
    def get_poi_test_list(self):
        '''This function is to get the poi_test_list of the user'''
        
        return self.poi_test_list
        
    def set_rec_list(self, poi_rec_list):
        '''This function is to set a user's poi_rec_list'''
        
        self.poi_rec_list = poi_rec_list
    
    def get_poi_rec_list(self):
        '''This function is to get the poi_rec_list of the user'''
        
        return self.poi_rec_list
    
    def isEqual(self, user2):
        '''This function is to tell if self and user2 are the same user'''
        
        if self.get_uid() == user2.get_uid():
            return True
        return False
        
    def set_topic_pref_list(self, topic_pref_list):
        '''This function is to add a topic_pref to the list'''
        
        self.topic_pref_list = topic_pref_list
    
    def get_topic_pref_list(self):
        return self.topic_pref_list
        
    def set_pr_topic_list(self, pr_topic_list):
        '''This function is to add a pr_topic to the list'''
        
        self.pr_topic_list = pr_topic_list
        
    def get_pr_topic_list(self):
        return self.pr_topic_list
        
    def add_other_pr_to_dic(self, uid, pr):
        '''This function is to add a pr value of other user based on personalization'''
        
        self.other_pr_dic[uid] = pr
        
    def get_other_pr_dic(self):
        return self.other_pr_dic
        

def get_all_poi_train_list(train_read_path):
    '''This function is to get all the poi (candidate locations)'''
    
    poi_train_list = []
    train_fp = open(train_read_path, 'r')
    line = train_fp.readline()
    while line != '':
        line_list = line.split(',')
        poi_id = line_list[-2]
        if poi_id not in poi_train_list:
            poi_train_list.append(poi_id)
        line = train_fp.readline()
    return poi_train_list


def tspr_fri_rec(read_write_dir, train_read_path, test_read_path, user_topic_dist_path, tspr_read_path, result_path):
    '''This function is to implement user-based cf in the train set'''
    
    train_fp = open(train_read_path, 'r')
    # list to store all user objects
    user_obj_list = []
    # record the index of a user in user_obj_list
    user_index_dic = {}
    i = -1
    ## get the poi and its w of each user from train set
    line = train_fp.readline()
    while line != '':
        line = line.strip('\n')
        line_list = line.split(',')
        uid = line_list[0]
        poi_id = line_list[3]
        w = line_list[4]
        #a new user come
        if uid not in user_index_dic:
            i += 1
            #set her index in user_index_dic
            user_index_dic[uid] = i
            # notice "userRec"
            user_obj = userRec(uid)
            #add the poi to poi_w_dic of a user
            user_obj.add_poi_w_to_dic(poi_id, w)
            #append her to the list
            user_obj_list.append(user_obj)
        #the user is already existing
        else:
            #get her index in the list
            user_index = user_index_dic[uid]
            #add the poi to her visited poi list
            user_obj_list[user_index].add_poi_w_to_dic(poi_id, w)
        line = train_fp.readline()
    train_fp.close()
    print "get all the users train records"
    ## get the poi test list of users
    test_fp = open(test_read_path, 'r')
    line = test_fp.readline()
    while line != '':
        line_list = line.split(',')
        uid = line_list[0]
        poi_id = line_list[3]
        # get the user object index in the user_index_dic
        user_index = user_index_dic[uid]
        # get the user object and add poi_id to test_list of the user
        user_obj_list[user_index].add_poi_to_test_list(poi_id)
        line = test_fp.readline()
    test_fp.close()
    print "get all users test records"
    ##  get user topic_pref_list
    user_topic_dist_fp = open(user_topic_dist_path, 'r')
    line = user_topic_dist_fp.readline()
    while line != '':
        line = line.strip('\n')
        #delete the '' in the end
        line_list = line.split(',')[0:-1]
        uid = line_list[0]
        topic_pref_list = line_list[1:]
        user_index = user_index_dic[uid]
        user_obj = user_obj_list[user_index]
        user_obj.set_topic_pref_list(topic_pref_list)
        line = user_topic_dist_fp.readline()
    user_topic_dist_fp.close()
    print "get user topic_pref_list"     
    ## get the user pr_topic_list
    tspr_fp = open(tspr_read_path, 'r')
    line = tspr_fp.readline()
    while line != '':
        line = line.strip('\n')
        #delete the '' in the end
        line_list = line.split(',')
        uid = line_list[0]
        pr_topic_list = line_list[1:]
        user_index = user_index_dic[uid]
        user_obj = user_obj_list[user_index]
        user_obj.set_pr_topic_list(pr_topic_list)
        line = tspr_fp.readline()
    tspr_fp.close()
    print "get user pr_topic_list"
    ## get set pr value of others based on self
    for i in range(0, 10):
        print i
    #for user_obj in user_obj_list:
        user_obj = user_obj_list[i]
        uid = user_obj.get_uid()
        topic_pref_list = user_obj.get_topic_pref_list()
        for user_obj2 in user_obj_list:
            pr_other = 0.0
            uid2 = user_obj2.get_uid()
            if user_obj.isEqual(user_obj2):
                continue
            else:
                pr_topic_list = user_obj2.get_pr_topic_list()
                for i in range(0, 20):
                    pr_other += float(topic_pref_list[i]) * float(pr_topic_list[i])
                user_obj.add_other_pr_to_dic(uid2, pr_other)
    print "get pr value of others based on self"

    ## get the recommendation list for every user
    # get poi cadidates (all poi) to recommend
    poi_cadidates_list = get_all_poi_train_list(train_read_path)
    i = 0
    for i in range(0, 10):
        print i
    #for user_obj in user_obj_list:
        user_obj = user_obj_list[i]
        #print user_obj.get_uid()
        other_pr_dic = user_obj.get_other_pr_dic()
        user_rec_dic = {}
        for poi_cad_id in poi_cadidates_list:
            score = 0.0
            for user_obj2 in user_obj_list:
                uid2 = user_obj2.get_uid()
                if user_obj.isEqual(user_obj2):
                    continue
                other_pr = other_pr_dic[uid2]
                other_w_of_poi = float(user_obj2.get_w_of_poi(poi_cad_id))
                score += other_pr * other_w_of_poi
            user_rec_dic[poi_cad_id] = score
        # [(poi_id,socre),...]
        top_rec_poi_s_list = sorted(user_rec_dic.items(), key = lambda x:x[1], reverse = True)[0:100]
        # [poi1, poi2, ...]        
        top_rec_poi_list = [poi_s[0] for poi_s in top_rec_poi_s_list]
        # set the poi_rec_list for the user
        user_obj.set_rec_list(top_rec_poi_list) 
    print "get recommend list for all users"
    # compute precision and recall
    precision_sum = [0.0 for i in range(0, 10)]
    recall_sum = [0.0 for i in range(0, 10)] 
    #for user_obj in user_obj_list:
    for i in range(0, 10):
        user_obj = user_obj_list[i]
        precision = [0.0 for i in range(0, 10)]
        recall = [0.0 for i in range(0, 10)]
        user_rec_list = user_obj.get_poi_rec_list()
        #print 'uid', user_obj.get_uid()
        #print "rec", user_rec_list
        user_test_set = set(user_obj.get_poi_test_list())
        #print "test", user_test_set
        user_test_poi_num = len(user_test_set)
        for j in range(0, 10):
            user_rec_set_j = set(user_rec_list[0:(j+1)*10])
            #print user_rec_set_i
            hit_num =  float(len(user_rec_set_j.intersection(user_test_set)))
            #print "hit_num", hit_num
            precision[j] = hit_num / (j*10 + 10)
            #print 'precision', precision[j]
            recall[j] = hit_num / user_test_poi_num
            precision_sum[j] += precision[j]
            recall_sum[j] += recall[j]
    # save the result
    user_num = len(user_obj_list)
    user_num  = 10
    result_fp = open(result_path, 'w')
    for j in range(0, 10):
        precision_average = precision_sum[j] / user_num
        #print precision_average
        recall_average = recall_sum[j] / user_num
        #print precision_average
        line = str(j*10+10) + '\t' + '%0.5f' % (precision_average) + '\t' + \
                '%0.5f' % (recall_average) + '\n'
        result_fp.write(line)
    result_fp.close()
    

def main():
    '''TSPR_based recommendation; Return result_tspr_city.txt file'''
    
    folder = 'pro'
    city = 'sf'
    read_write_dir = 'C:/Users/GuoQing/Desktop/data/foursquare_' + folder
    train_read_path = read_write_dir + '/train_' + city + '.txt'
    test_read_path = read_write_dir + '/test_' + city + '.txt'
    tspr_read_path = read_write_dir + '/tspr_friend_' + city +'.txt'
    user_topic_dist_path = read_write_dir + '/user_topic_dist_' + city + '.txt'
    result_path = read_write_dir + '/result_tspr_friend_' + city + '.txt'
    tspr_fri_rec(read_write_dir, train_read_path, test_read_path, user_topic_dist_path, tspr_read_path, result_path)
    
    print "===over==="
    
    
if __name__ == '__main__':
    main()