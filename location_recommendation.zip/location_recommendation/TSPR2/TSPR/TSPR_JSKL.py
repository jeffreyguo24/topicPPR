# -*- coding: utf-8 -*-
"""
Created on Thu Nov 13 19:01:24 2014

This file is to run TSPR 

@author: guoqing
"""

#import networkx as nx
from pagerank import pagerank
from pygraph.classes.digraph import digraph
from math import log

class user:
    def __init__(self, uid):
        self.uid = uid
        self.friend_list = []
        self.poi_w_dic = {}
        self.place_friend_list = []
        self.place_friend_sim_dic = {}
    
    def get_uid(self):
        return self.uid
    
    def set_friend_list(self, friend_list):
        self.friend_list = friend_list
        
    def get_friend_list(self):
        return self.friend_list
    
    def get_friend_num(self):
        return len(self.get_friend_list())
    
    def add_poi_w_to_dic(self, poi_id, w_t):
        '''This function is to add a poi and its w to poi_w_dic'''
        
        if poi_id not in self.poi_w_dic:
            self.poi_w_dic[poi_id] = w_t
    
    def get_poi_w_dic(self):
        '''This function is to get the poi_w_dic of a user'''
        
        return self.poi_w_dic
        
    def get_w_of_poi(self, poi_id):
        '''This function is to get the w of a poi of a user'''
        
        poi_w_dic = self.get_poi_w_dic()
        if poi_id not in poi_w_dic:
            return 0.0
        return poi_w_dic[poi_id]
        
    def add_user_to_place_friend_list(self, uid):
        '''add a place friend to the list'''
        
        self.place_friend_list.append(uid)
        
    def get_place_friend_list(self):
        return self.place_friend_list
        
    def get_place_friend_num(self):
        return len(self.get_place_friend_list())
        
    def set_place_friend_sim_dic(self, place_friend_sim_dic):
        self.place_friend_sim_dic = place_friend_sim_dic
    
    def get_place_friend_sim_dic(self):
        return self.place_friend_sim_dic


def normal(dic):
    '''This funtion is for normalization'''
    
    sum0 = 0.0
    for key in dic:
        value = dic[key]
        sum0 += value
    
    for key in dic:
        dic[key] = dic[key] / sum0
    
    return dic
   
   
def KL_dist(a,b):

    return 0.5 * (a*log(a/b) + b*log(b/a))
    

def JS_KL_dist(a,b):

    c = 0.5 * (a+b)
    return 0.5 * (a*log(a/c) + b*log(b/c))


def get_cos_sim(user1, user2):
    '''This function is to get the cosine similarity given two user objects'''
    
    # ?? divider, ??? upper
    cos_sim = 0.0; upper = 0.0; 
    divider = 0.0
    user1_poi_w_t_dic = user1.get_poi_w_dic()
    user2_poi_w_t_dic = user2.get_poi_w_dic()
    # get upper
    for poi_id in user1_poi_w_t_dic:
        # if user2 also visited poi
        if poi_id in user2_poi_w_t_dic:
            upper += (float(user1_poi_w_t_dic[poi_id]) * float(user2_poi_w_t_dic[poi_id]))
    # get divider
    w_square_sum1 = 0.0
    for poi_id in user1_poi_w_t_dic:
        w_square_sum1 += float(user1_poi_w_t_dic[poi_id]) ** 2
    w_square_sum2 = 0.0
    for poi_id in user2_poi_w_t_dic:
        w_square_sum2 += float(user2_poi_w_t_dic[poi_id]) ** 2
    divider = (w_square_sum1 ** 0.5) * (w_square_sum2 ** 0.5)
    # get the similarity
    cos_sim = upper / divider
    return cos_sim


def get_node_edge(topic_id, read_write_dir, train_read_path, user_topic_dist_path, city):
    '''this funtion is to get normalized edge weight'''
    
    train_fp = open(train_read_path, 'r')
    # list to store all user objects
    user_obj_list = []
    # record the index of a user in user_obj_list
    user_index_dic = {}
    i = -1
    # get the poi and its w of each user
    line = train_fp.readline()
    while line != '':
        line = line.strip('\n')
        line_list = line.split(',')
        uid = line_list[0]
        poi_id = line_list[3]
        w = line_list[4]
        #a new user come
        if uid not in user_index_dic:
            i += 1
            #set her index in user_index_dic
            user_index_dic[uid] = i
            # notice "userRec"
            user_obj = user(uid)
            #add the poi to poi_w_dic of a user
            user_obj.add_poi_w_to_dic(poi_id, w)
            #append her to the list
            user_obj_list.append(user_obj)
        #the user is already existing
        else:
            #get her index in the list
            user_index = user_index_dic[uid]
            #add the poi to her visited poi list
            user_obj_list[user_index].add_poi_w_to_dic(poi_id, w)
        line = train_fp.readline()
    train_fp.close()
    print "get all the users train records"
    
    # get the place friend of each user
    for user_obj1 in user_obj_list:
        uid1 = user_obj1.get_uid()
        poi_w_dic1 = user_obj1.get_poi_w_dic()
        poi_list1 = [key for key in poi_w_dic1.keys()]
        poi_set1 = set(poi_list1)
        for user_obj2 in user_obj_list:
            uid2 = user_obj2.get_uid()
            if uid1 == uid2:
                continue
            else:
                poi_w_dic2 = user_obj2.get_poi_w_dic()
                poi_list2 = [key for key in poi_w_dic2.keys()]
                poi_set2 = set(poi_list2)
                if len(poi_set1.intersection(poi_set2)) > 0:
                    user_obj1.add_user_to_place_friend_list(uid2)
    print "get all the place friend of each user"
    
    # get users' topic preference
    user_topic_dist_path = read_write_dir + '/user_topic_dist_' + city + '.txt'
    user_topic_dist_fp = open(user_topic_dist_path, 'r')
    user_pref_topic_dic = {}
    line = user_topic_dist_fp.readline()
    while line != '':
        # delete '\n' and '' in the end of the line
        line_list = line.split(',')[0:-1]
        uid = line_list[0]
        pref_topic = float(line_list[topic_id + 1])
        user_pref_topic_dic[uid] = pref_topic
        line = user_topic_dist_fp.readline()
    user_topic_dist_fp.close()    
    
    # set the topic link similarity between two place friends
    for user_obj1 in user_obj_list:
        uid1 = user_obj1.get_uid()
        place_friend_list = user_obj1.get_place_friend_list()
        user_sim_dic = {}
        for place_friend in place_friend_list:
            user2_index = user_index_dic[place_friend]
            user_obj2 = user_obj_list[user2_index]
            uid2 = user_obj2.get_uid()
            # !!! modify sim5
            weight = get_cos_sim(user_obj1, user_obj2) * JS_KL_dist(user_pref_topic_dic[uid1],user_pref_topic_dic[uid2])
            user_sim_dic[place_friend] = weight
        if not user_sim_dic == {}:
            user_sim_norm_dic = normal(user_sim_dic)
        user_obj1.set_place_friend_sim_dic(user_sim_norm_dic)
        
    return user_obj_list


def prepare_G(topic_id, read_write_dir, train_read_path, user_topic_dist_path, city):
    '''This function is to create a graph object'''
    
    user_obj_list = get_node_edge(topic_id, read_write_dir, train_read_path, user_topic_dist_path, city)
    print "get user and their place friend with weight"    
    
    # construct the directed graph 
    DG = digraph()
    
    for user_obj1 in user_obj_list:
        uid1 = user_obj1.get_uid()
        if not DG.has_node(uid1):
            DG.add_node(uid1)
        place_friend_sim_dic = user_obj1.get_place_friend_sim_dic()
        for place_friend in place_friend_sim_dic:
            if not DG.has_node(place_friend):
                DG.add_node(place_friend)
            weight = place_friend_sim_dic[place_friend]
            DG.add_edge((uid1, place_friend), weight)
            
    return DG
    

def get_personal_vec_dic(topic_id, read_write_dir, city):
    '''This function is to get the personal vector dict'''
    
    user_topic_dist_path = read_write_dir + '/user_topic_dist_' + city + '.txt'
    user_topic_dist_fp = open(user_topic_dist_path, 'r')
    user_personal_dic = {}
    line = user_topic_dist_fp.readline()
    while line != '':
        # delete '\n' and '' in the end of the line
        line_list = line.split(',')[0:-1]
        uid = line_list[0]
        personal = float(line_list[topic_id + 1])
        user_personal_dic[uid] = personal
        line = user_topic_dist_fp.readline()
    user_topic_dist_fp.close()
    
    user_personal_norm_dic = normal(user_personal_dic)
    return user_personal_norm_dic


def get_topic_PR(topic_id, read_write_dir, train_read_path, tspr_write_path, city):
    '''This function is to run tspr'''
    
    # prepare the graph object
    user_personal_dic = get_personal_vec_dic(topic_id, read_write_dir, city)
    user_topic_dist_path = read_write_dir + '/user_topic_dist_' + city + '.txt'
    print "get user_start_dic"
    DG = prepare_G(topic_id, read_write_dir, train_read_path, user_topic_dist_path, city)
    print "get DG"
    user_pr_dic = pagerank(DG, personalization=user_personal_dic)
    del DG
    tspr_write_fp = open(tspr_write_path, 'w')
    for uid in user_pr_dic:
        user_pr = user_pr_dic[uid] 
        line = uid + ',' + str(user_pr) + '\n'
        tspr_write_fp.write(line)
    tspr_write_fp.close()
    

def aggregate_tspr(read_write_dir, tspr_aggre_write_path, city):
    '''This function is to aggregate all the topic pr txt'''
    
    user_pr_t_dic = {}
    for i in range(0, 20):
        topic_id = i
        tspr_read_path = read_write_dir + '/TSPR_' + city + '/' + str(topic_id) + '.txt'
        tspr_fp = open(tspr_read_path, 'r')
        line = tspr_fp.readline()
        while line != '':
            line = line.strip('\n')
            line_list = line.split(',')
            uid = line_list[0]
            pr_t = line_list[1]
            if uid not in user_pr_t_dic:
                user_pr_t_dic[uid] = [pr_t]
            else:
                user_pr_t_dic[uid].append(pr_t)
            line = tspr_fp.readline()
        tspr_fp.close()
    tspr_aggre_write_fp = open(tspr_aggre_write_path, 'w')
    for uid in user_pr_t_dic:
        pr_t_list = user_pr_t_dic[uid]
        line = uid + ',' + ','.join(pr_t_list) + '\n'
        tspr_aggre_write_fp.write(line)
    tspr_aggre_write_fp.close()


def main():
    folder = 'ny'
    read_write_dir = 'C:/Users/GuoQing/Desktop/data/foursquare_' + folder
    city = 'ny'
    # there are 20 topics, so run PR 20 times
    train_read_path = read_write_dir + '/train_' + city + '.txt'
    
    for i in range(18,20):
        print i
        topic_id = i
        tspr_write_path = read_write_dir + '/TSPR_JSKL_' + city + '/' + str(i) + '.txt'
        get_topic_PR(topic_id, read_write_dir, train_read_path, tspr_write_path, city)
        
    tspr_aggre_write_path = read_write_dir + '/tspr_jskl_' + city + '.txt'
    aggregate_tspr(read_write_dir, tspr_aggre_write_path, city)
    print "aggregate user_pr_t"
    print "===over==="
    
    
if __name__ == '__main__':
    main()
    