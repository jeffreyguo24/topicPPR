# -*- coding: utf-8 -*-
"""
Created on Fri Nov 21 17:09:02 2014

@author: guoqing
"""

from pygraph.classes.digraph import digraph

def normal(dic):
    '''This funtion is for normalization'''
    
    sum0 = 0.0
    for key in dic:
        value = dic[key]
        sum0 += value
    
    for key in dic:
        dic[key] = dic[key] / sum0
    
    return dic


def pagerank(graph, damping_factor=0.85, personalization=None, max_iterations=100, \
             min_delta=1e-6):
    """
    Compute and return the PageRank in an directed graph.    
    
    @type  graph: digraph
    @param graph: Digraph.
    
    @type  damping_factor: number
    @param damping_factor: PageRank dumping factor.
    
    @type  max_iterations: number 
    @param max_iterations: Maximum number of iterations.
    
    @type  min_delta: number
    @param min_delta: Smallest variation required for a new iteration.
    
    @rtype:  Dict
    @return: Dict containing all the nodes PageRank.
    """
    
    nodes = graph.nodes()
    graph_size = len(nodes)
    if graph_size == 0:
        return {}
    # value for nodes without inbound links
    min_value = (1.0-damping_factor)/graph_size 
    #min_value = 0.0000001
        
    # itialize the page rank dict with 1/N for all nodes
    pagerank = dict.fromkeys(nodes, 1.0/graph_size)
    #pagerank = dict.fromkeys(nodes, 1.0)
    #pagerank = personalization
        
    for i in range(max_iterations):
        diff = 0 #total difference compared to last iteraction
        # computes each node PageRank based on inbound links
        for node in nodes:
            rank = min_value
            for referring_page in graph.incidents(node):
                rank += (damping_factor * pagerank[referring_page] * (graph.edge_weight((referring_page, node)))\
                        + (1-damping_factor) * personalization[node])
                            
                #rank += damping_factor * pagerank[referring_page] / \
                 #       len(graph.neighbors(referring_page))
            diff += abs(pagerank[node] - rank)
            pagerank[node] = rank
        normal(pagerank)
        
        #stop if PageRank has converged
        if diff < min_delta:
            break
    
    return pagerank
 
 
def main():

    # Graph creation
    gr = digraph()
 
    # Add nodes and edges
    gr.add_nodes(["1","2","3","4"])
    
    
    gr.add_edge(("1","2"), 0.3333)
    gr.add_edge(("1","3"), 0.3333)
    gr.add_edge(("1","4"), 0.3333)
    gr.add_edge(("2","3"), 0.5)
    gr.add_edge(("2","4"), 0.5)
    gr.add_edge(("3","4"), 0.5)
    gr.add_edge(("3","2"), 0.5)
    #gr.add_edge(("4","2"), 0.7)
    
    '''
    gr.add_edge(("1","2"))
    gr.add_edge(("1","3"))
    gr.add_edge(("1","4"))
    gr.add_edge(("2","3"))
    gr.add_edge(("2","4"))
    gr.add_edge(("3","4"))
    gr.add_edge(("4","2"))
    '''
    personalization = {'1':0.1, '2':0.2, '3':0.3, '4':0.4}
    pagerank(gr, personalization = personalization)
    
    
if __name__ == '__main__':
    main()
    

 
