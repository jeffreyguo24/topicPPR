# -*- coding: utf-8 -*-

def get_user_home(train_path, user_home_path):
    '''This function is to get home of each user
        Home is the center of top-k check-in poi'''
        
    train_fp = open(train_path, 'r')
    user_obj_list = []
    # record the index of a user in user_obj_list
    user_index_dic = {}
    i = -1
    # get the poi and its w of each user
    line = train_fp.readline()
    while line != '':
        line = line.strip('\n')
        line_list = line.split(',')
        uid = line_list[0]
        lat = line_list[1]
        lon = line_list[2]
        poi_id = line_list[3]
        w = float(line_list[4])
        #a new user come
        if uid not in user_index_dic:
            i += 1
            # set her index in user_index_dic
            user_index_dic[uid] = i
            # notice "userRec"
            user_obj = user(uid)
            # add the poi to poi_w_dic of a user
            user_obj.add_poi_w_to_dic(poi_id, w)
            # add the poi, lat, lon 
            user_obj.add_poi_lat_lon_to_dic(poi_id, lat, lon)
            #append her to the list
            user_obj_list.append(user_obj)
        #the user is already existing
        else:
            #get her index in the list
            user_index = user_index_dic[uid]
            #add the poi to her visited poi list
            user_obj_list[user_index].add_poi_w_to_dic(poi_id, w)
            # add the poi, lat, lon 
            user_obj.add_poi_lat_lon_to_dic(poi_id, lat, lon)
        line = train_fp.readline()
    train_fp.close()
    # get the home of each user
    user_home_fp = open(user_home_path, 'w')
    top_k = 2
    for user_obj in user_obj_list:
        uid = user_obj.get_uid()
        user_poi_w_dic = user_obj.get_poi_w_dic()
        user_poi_lat_lon_dic = user_obj.get_poi_lat_lon_dic()
        top3_poi_w_list = sorted(user_poi_w_dic.items(), key = lambda x:x[1], reverse = True)[0:top_k]
        lat_average = 0.0; lon_average = 0.0        
        for poi_w in top3_poi_w_list:
            #print poi_w
            poi_id = poi_w[0]
            lat_lon_tuple = user_poi_lat_lon_dic[poi_id]
            lat_average += float(lat_lon_tuple[0])
            lon_average += float(lat_lon_tuple[1])
        lat_average = lat_average/top_k
        lon_average = lon_average/top_k
        line = uid + ',' + str(lat_average) + ',' + str(lon_average) + '\n'
        user_home_fp.write(line)
    user_home_fp.close()


def main():
    folder = 'ny'
    read_write_dir = 'C:/Users/GuoQing/Desktop/data/foursquare_' + folder
    city = 'ny'
    train_path = read_write_dir + '/train_'+ city +'.txt'
    
    ## get each user's home
    user_home_path = read_write_dir + '/user_home_'+ city +'.txt'   
    get_user_home(train_path, user_home_path)
    print "get users' home"
    

if __name__ == '__main__':
    main()
    
    
    