# -*- coding: utf-8 -*-

from math import pi, sqrt, cos, sin, asin, acos, ceil, log, floor
import numpy as np
from scipy import stats
import os

class user:
    '''This class is to describe a user's profile in the train set
        and it's used for implementing user-based cf'''
    
    def __init__(self, uid = None):
        self.uid = uid
        self.poi_w_dic = {}
        self.poi_test_list = []
        self.poi_rec_list = []
        self.topic_pref_list = []
        self.pr_topic_list = []
        self.other_pr_dic = {}
        self.home = None
        self.kernel = None
        self.xy_list = []
    
    def get_uid(self):
        return self.uid
    
    def add_poi_w_to_dic(self, poi_id, w):
        '''This function is to add a poi and its w to poi_w_dic'''
        
        if poi_id not in self.poi_w_dic:
            self.poi_w_dic[poi_id] = w
    
    def get_poi_w_dic(self):
        '''This function is to get the poi_w_dic of a user'''
        
        return self.poi_w_dic
        
    def get_w_of_poi(self, poi_id):
        '''This function is to get the w of a poi of a user'''
        
        poi_w_dic = self.get_poi_w_dic()
        if poi_id not in poi_w_dic:
            return 0.0
        return poi_w_dic[poi_id]
        
    def add_poi_to_test_list(self, poi_id):
        '''This function is to add a poi to a user's poi_test_list'''
        
        if poi_id not in self.poi_test_list:
            self.poi_test_list.append(poi_id)
    
    def get_poi_test_list(self):
        '''This function is to get the poi_test_list of the user'''
        
        return self.poi_test_list
        
    def set_rec_list(self, poi_rec_list):
        '''This function is to set a user's poi_rec_list'''
        
        self.poi_rec_list = poi_rec_list
    
    def get_poi_rec_list(self):
        '''This function is to get the poi_rec_list of the user'''
        
        return self.poi_rec_list
    
    def isEqual(self, user2):
        '''This function is to tell if self and user2 are the same user'''
        
        if self.get_uid() == user2.get_uid():
            return True
        return False
        
    def set_topic_pref_list(self, topic_pref_list):
        '''This function is to add a topic_pref to the list'''
        
        self.topic_pref_list = topic_pref_list
    
    def get_topic_pref_list(self):
        return self.topic_pref_list
        
    def set_pr_topic_list(self, pr_topic_list):
        '''This function is to add a pr_topic to the list'''
        
        self.pr_topic_list = pr_topic_list
        
    def get_pr_topic_list(self):
        return self.pr_topic_list
        
    def add_other_pr_to_dic(self, uid, pr):
        '''This function is to add a pr value of other user based on personalization'''
        
        self.other_pr_dic[uid] = pr
        
    def get_other_pr_dic(self):
        return self.other_pr_dic
    
    def set_home(self, home):
        self.home = home
        
    def get_home(self):
        return self.home
        
    def set_kernel(self, kernel):
        self.kernel = kernel
        
    def get_kernel(self):
        return self.kernel
    
    def add_xy_to_xylist(self, x, y):
        self.xy_list.append((x,y))
        
    def get_xylist(self):
        return self.xy_list
         

def get_all_poi_train_list(train_read_path):
    '''This function is to get all the poi (candidate locations)'''
    
    poi_train_list = []
    train_fp = open(train_read_path, 'r')
    line = train_fp.readline()
    while line != '':
        line_list = line.split(',')
        poi_id = line_list[-2]
        if poi_id not in poi_train_list:
            poi_train_list.append(poi_id)
        line = train_fp.readline()
    return poi_train_list


def compute_geodist(lat1, lon1, lat2, lon2):
    rad_lat1 = lat1*pi/180.0
    rad_lat2 = lat2*pi/180.0
    phi = rad_lat1 - rad_lat2
    lambdaa = lon1*pi/180.0 - lon2*pi/180.0
    u = sin(phi/2.0)
    v = sin(lambdaa/2.0)
    s = 2*asin(sqrt(u * u + cos(rad_lat1) * cos(rad_lat2) * v * v))
    return s * 6378.137

import matplotlib
import matplotlib.pyplot as plt
def get_kernel(user_obj):
    
    xylist = user_obj.get_xylist()
    xlist = []; ylist = []
    for xy in xylist:
        xlist.append(xy[0])
        ylist.append(xy[1])
        
    #m1, m2 = measure(10)
    m1 = np.array(xlist, dtype=np.float)
    m2 = np.array(ylist, dtype=np.float)
    xmin = m1.min()-5
    xmax = m1.max()+5
    ymin = m2.min()-5
    ymax = m2.max()+5

    #print type(m1)
    #Perform a kernel density estimate on the data:
    
    X, Y = np.mgrid[xmin:xmax:100j, ymin:ymax:100j]
    positions = np.vstack([X.ravel(), Y.ravel()])
    values = np.vstack([m1, m2])
    
    kernel = stats.gaussian_kde(values)

    #Plot the results:
    if user_obj.get_uid() == test_user:
        Z = np.reshape(kernel(positions).T, X.shape)
    
        #fig = plt.figure()
        fig = plt.figure(figsize=(20,10), dpi=98)
        ax = fig.add_subplot(111)
        ax.set_ylabel("y (km)",fontsize=22)
        ax.set_xlabel("x (km)",fontsize=22)
        for label in ax.xaxis.get_ticklabels():
            label.set_fontsize(18)
        for label in ax.yaxis.get_ticklabels():
            label.set_fontsize(18) 
        cax = ax.imshow(np.rot90(Z), cmap=plt.cm.gist_earth_r,
                  extent=[xmin, xmax, ymin, ymax])
        ax.plot(m1, m2, 'ko', markersize=6)
        ax.set_xlim([xmin, xmax])
        ax.set_ylim([ymin, ymax])
        
        # show color bar
        cset = plt.contour(X,Y,Z)
        plt.clabel(cset, inline=1, fontsize=10)
        plt.colorbar(cax)
        #cbar = fig.colorbar(cax, ticks=[0, 0.005,0.01], orientation='vertical')
        #cbar.ax.set_yticklabels(['Low', 'Medium', 'High'])# horizontal colorbar
        
        plt.show()
        pic_path = 'C:/Users/I314279/Desktop/' + test_user + '.eps'
        #plt.savefig()	
        matplotlib.rcParams['figure.figsize']#图片像素
        matplotlib.rcParams['savefig.dpi']#分辨率
        plt.savefig(pic_path, format = 'eps')#指定分辨率
        #默认的像素：[8.0,6.0]，分辨率为100，指定dpi=200，图片尺寸为1600*1200
    
    return kernel


from scipy import integrate
def get_kernel_sim_integrate(user_obj, user_obj2, xy_range):
    
    kernel1 = user_obj.get_kernel()
    kernel2 = user_obj2.get_kernel()
    xmin = xy_range[0]; ymin = xy_range[2]
    xmax = xy_range[1]; ymax = xy_range[3]
    # defind the distance of a position
    def f(x, y):
        xx = np.array([x], dtype=np.float)
        yy = np.array([y], dtype=np.float)
        xy = np.vstack([xx, yy])
        dist = abs(kernel1(xy)[0] - kernel2(xy)[0])
        return dist
    area = integrate.nquad(f, [[xmin, xmax],[ymin, ymax]])
    kernel_sim = 1.0 - area[0]
    return kernel_sim
    
    
def get_kernel_sim_product(user_obj, user_obj2, xy_range):
    
    kernel1 = user_obj.get_kernel()
    kernel2 = user_obj2.get_kernel()
    
    kernel_sim = kernel1.integrate_kde(kernel2)
    return kernel_sim
    
    
def get_kernel_sim_sampling(user_obj, user_obj2, xy_range):
    
    kernel1 = user_obj.get_kernel()
    kernel2 = user_obj2.get_kernel()
    
    #print "start to get kernel sim"
    #xmin = 10*int(xy_range[0]); ymin = 10*int(xy_range[2])
    #xmax = 10*int(xy_range[1]); ymax = 10*int(xy_range[3])
    #print xmin, xmax, ymin, ymax
    
    xmin = xy_range[0]; ymin = xy_range[2]
    xmax = xy_range[1]; ymax = xy_range[3]
    
    # defind the distance of a position
    area = 0.0
    def f(x, y):
        xx = np.array([x], dtype=np.float)
        yy = np.array([y], dtype=np.float)
        xy = np.vstack([xx, yy])
        dist = abs(kernel1(xy)[0] - kernel2(xy)[0])
        #print 'dst', dist
        return dist

    i = xmin; j = ymin
    while i<=xmax:
        while j<=ymax:
            #print i, j
            area += f(i, j)
            j += 0.1
        i += 0.1
        
    kernel_sim = 1.0/area
    return kernel_sim
  

def get_kernel_sim_xy(user_obj, user_obj2):
    '''this function is to get two users' kernel similarity'''
    
    xlist = []; ylist = []
    xylist = user_obj.get_xylist()
    for xy in xylist:
        xlist.append(xy[0])
        ylist.append(xy[1])
    xylist = list(set(user_obj.get_xylist()))
    kernel = user_obj.get_kernel()
    
    xlist2 = []; ylist2 = []
    xylist2 = user_obj2.get_xylist()
    for xy in xylist2:
        xlist2.append(xy[0])
        ylist2.append(xy[1])
    xylist2 = list(set(user_obj2.get_xylist()))
    kernel2 = user_obj2.get_kernel()
    
    def f1(x, y):
        xx = np.array([x], dtype=np.float)
        yy = np.array([y], dtype=np.float)
        xy = np.vstack([xx, yy])
        dist = (abs(kernel(xy)[0] - kernel2(xy)[0])**2) / (kernel(xy)[0] + kernel2(xy)[0])
        #dist = kernel(xy)[0]*log(kernel(xy)[0]/kernel2(xy)[0],e)
        return dist
    
    def f2(x, y):
        xx = np.array([x], dtype=np.float)
        yy = np.array([y], dtype=np.float)
        xy = np.vstack([xx, yy])
        try:
            dist = (kernel2(xy)[0]*log(kernel2(xy)[0], e) + kernel(xy)[0]*log(kernel(xy)[0], e))/2-\
                (kernel2(xy)[0]+kernel(xy)[0])/2 * log((kernel2(xy)[0]+kernel(xy)[0])/2)
        except:
            return 0.0
        #dist = kernel2(xy)[0]*log(kernel2(xy)[0]/kernel(xy)[0],e)
        return dist
        
    N1 = len(xylist); N2=len(xylist2)
    N=N1+N2
    
    dist_sum = 0.0
    for i in range(0, N1):
        x = xlist[i]; y=ylist[i]
        dist_sum += f1(x, y)
    for j in range(0, N2):
        x = xlist2[j]; y=ylist2[j]
        dist_sum += f1(x, y)
    #print dist_sum
    #kernel_sim = dist_sum
    kernel_sim = 1- dist_sum/N
    
    return kernel_sim**2


def get_user_pair_key(uid, uid2):
    '''get the right user pair key'''    
    
    uid1 = int(uid)
    uid2 = int(uid2)
    
    return (str(min(uid1, uid2)), str(max(uid1, uid2)))
  

def normal(dic):
    '''This funtion is for normalization'''
    
    sum0 = 0.0
    for key in dic:
        value = dic[key]
        sum0 += value
    
    for key in dic:
        dic[key] = dic[key] / sum0
    
    return dic
    
   
def get_kernel_sim_file(read_write_dir, train_kernel_path, kernel_sim_path, xy_range):
    '''This function is to implement user-based cf in the train set'''
    
    train_kernel_fp = open(train_kernel_path, 'r')
    # list to store all user objects
    user_obj_list = []
    # record the index of a user in user_obj_list
    user_index_dic = {}
    i = -1
    ## get the poi and its w of each user from train set
    line = train_kernel_fp.readline()
    while line != '':
        line = line.strip('\n')
        line_list = line.split(',')
        uid = line_list[0]
        x = float(line_list[1])
        y = float(line_list[2])
        #a new user come
        if uid not in user_index_dic:
            i += 1
            #set her index in user_index_dic
            user_index_dic[uid] = i
            # notice "userRec"
            user_obj = user(uid)
            #add the a x y of a user
            user_obj.add_xy_to_xylist(x, y)
            #append her to the list
            user_obj_list.append(user_obj)
        #the user is already existing
        else:
            #get her index in the list
            user_index = user_index_dic[uid]
            user_obj_list[user_index].add_xy_to_xylist(x, y)
        line = train_kernel_fp.readline()
    train_kernel_fp.close()
    print "get all the users x y lists records"
    
    # get kernel for each user
    for user_obj in user_obj_list:
        if user_obj.get_uid()==test_user:
            kernel = get_kernel(user_obj)
            user_obj.set_kernel(kernel)
    print "set kernel for each user"
    
    '''
    # save the kernel similarity of users in a file
    processed_user_list = []
    kernel_sim_fp = open(kernel_sim_path, 'w')
    i = 0
    for user_obj in user_obj_list:
        print i
        i+=1
        user_kernel_dic = {}
        uid = user_obj.get_uid()
        # 111, 4614 ,5239, 5334 
        if uid != test_user: break
        for user_obj2 in user_obj_list:
            uid2 = user_obj2.get_uid()
            if user_obj.isEqual(user_obj2) or (uid2 in processed_user_list):
                continue
            user_pair_key = get_user_pair_key(uid, uid2)
            
            # modify !!!
            #kernel_sim = get_kernel_sim_integrate(user_obj, user_obj2, xy_range)
            #kernel_sim = get_kernel_sim_sampling(user_obj, user_obj2, xy_range)
            kernel_sim = get_kernel_sim_product(user_obj, user_obj2, xy_range)
            user_kernel_dic[user_pair_key] = kernel_sim
        user_kernel_norm_dic = normal(user_kernel_dic)
        for user_pair_key in user_kernel_norm_dic:
            kernel_sim = user_kernel_norm_dic[user_pair_key]
            line = user_pair_key[0] + ',' + user_pair_key[1] + ',' + str(kernel_sim) + '\n'
            kernel_sim_fp.write(line)
        processed_user_list.append(user_obj.get_uid())
    kernel_sim_fp.close()
    print "get kernel sim file"
    '''

test_user = '832'
#3006, 832


def main():
    
    root = 'gowalla_'
    folder = 'la'
    city = 'la'
    #sf
    #xy_range = (xmin, xmax, ymin, ymax)
    xy_range = (-9, 15, -17, 7)
    #xy_range = (-425, 181, -31, 469)
    #lat_lon_range = (-122.51399517, 37.09494373, -121.64650252, 37.828603)
        
    print "=========\n" + root + folder + " get kernel_sim file running \n========="
    
    read_write_dir = os.path.join(r'C:\Users\I314279\GQ\data', root + folder)
    train_kernel_path = os.path.join(read_write_dir, 'train_kernel_' + city + '.txt')
    
    # modify !!!
    #kernel_sim_path = read_write_dir + '/kernel_sampling_sim_' + city + '.txt'
    #kernel_sim_path = read_write_dir + '/kernel_integrate_sim_' + city + '.txt'
    kernel_sim_path = os.path.join(read_write_dir, 'kernel_product_sim_test_' + city + '.txt')
    get_kernel_sim_file(read_write_dir, train_kernel_path, kernel_sim_path, xy_range)
    print "=========\n" + root + folder + " get kernel_sim file over \n========="

if __name__ == '__main__':
    main()
    