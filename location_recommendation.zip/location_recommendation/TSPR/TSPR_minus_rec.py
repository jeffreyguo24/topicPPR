# -*- coding: utf-8 -*-
"""
Created on Fri Nov 14 13:15:24 2014

This script is to do recommendation based on tspr

@author: guoqing
"""


class userRec:
    '''This class is to describe a user's profile in the train set
        and it's used for implementing user-based cf'''
    
    def __init__(self, uid = None):
        self.uid = uid
        self.poi_w_dic = {}
        self.poi_test_list = []
        self.poi_rec_list = []
        self.topic_pref_list = []
        self.pr_topic_list = []
        self.other_pr_dic = {}
    
    def get_uid(self):
        return self.uid
    
    def add_poi_w_to_dic(self, poi_id, w):
        '''This function is to add a poi and its w to poi_w_dic'''
        
        if poi_id not in self.poi_w_dic:
            self.poi_w_dic[poi_id] = w
    
    def get_poi_w_dic(self):
        '''This function is to get the poi_w_dic of a user'''
        
        return self.poi_w_dic
        
    def get_w_of_poi(self, poi_id):
        '''This function is to get the w of a poi of a user'''
        
        poi_w_dic = self.get_poi_w_dic()
        if poi_id not in poi_w_dic:
            return 0.0
        return poi_w_dic[poi_id]
        
    def add_poi_to_test_list(self, poi_id):
        '''This function is to add a poi to a user's poi_test_list'''
        
        if poi_id not in self.poi_test_list:
            self.poi_test_list.append(poi_id)
    
    def get_poi_test_list(self):
        '''This function is to get the poi_test_list of the user'''
        
        return self.poi_test_list
        
    def set_rec_list(self, poi_rec_list):
        '''This function is to set a user's poi_rec_list'''
        
        self.poi_rec_list = poi_rec_list
    
    def get_rec_list(self):
        '''This function is to get the poi_rec_list of the user'''
        
        return self.poi_rec_list
    
    def isEqual(self, user2):
        '''This function is to tell if self and user2 are the same user'''
        
        if self.get_uid() == user2.get_uid():
            return True
        return False
        
    def set_topic_pref_list(self, topic_pref_list):
        '''This function is to add a topic_pref to the list'''
        
        self.topic_pref_list = topic_pref_list
    
    def get_topic_pref_list(self):
        return self.topic_pref_list
        
    def set_pr_topic_list(self, pr_topic_list):
        '''This function is to add a pr_topic to the list'''
        
        self.pr_topic_list = pr_topic_list
        
    def get_pr_topic_list(self):
        return self.pr_topic_list
        
    def add_other_pr_to_dic(self, uid, pr):
        '''This function is to add a pr value of other user based on personalization'''
        
        self.other_pr_dic[uid] = pr
        
    def get_other_pr_dic(self):
        return self.other_pr_dic
        

def get_all_poi_train_list(train_read_path):
    '''This function is to get all the poi (candidate locations)'''
    
    poi_train_list = []
    train_fp = open(train_read_path, 'r')
    line = train_fp.readline()
    while line != '':
        line = line.strip('\n')
        line_list = line.split(',')
        poi_id = line_list[3]
        if poi_id not in poi_train_list:
            poi_train_list.append(poi_id)
        line = train_fp.readline()
    return poi_train_list


def tspr_rec(read_write_dir, train_read_path, test_read_path, user_topic_dist_path, tspr_read_path, result_path, rec_list_path, topic_num):
    '''This function is to implement user-based cf in the train set'''
    
    train_fp = open(train_read_path, 'r')
    # list to store all user objects
    user_obj_list = []
    # record the index of a user in user_obj_list
    user_index_dic = {}
    i = -1
    ## get the poi and its w of each user from train set
    line = train_fp.readline()
    while line != '':
        line = line.strip('\n')
        line_list = line.split(',')
        uid = line_list[0]
        poi_id = line_list[3]
        w = line_list[4]
        #a new user come
        if uid not in user_index_dic:
            i += 1
            #set her index in user_index_dic
            user_index_dic[uid] = i
            # notice "userRec"
            user_obj = userRec(uid)
            #add the poi to poi_w_dic of a user
            user_obj.add_poi_w_to_dic(poi_id, w)
            #append her to the list
            user_obj_list.append(user_obj)
        #the user is already existing
        else:
            #get her index in the list
            user_index = user_index_dic[uid]
            #add the poi to her visited poi list
            user_obj_list[user_index].add_poi_w_to_dic(poi_id, w)
        line = train_fp.readline()
    train_fp.close()
    print "get all the users train records"
    
    ## get the poi test list of users
    test_fp = open(test_read_path, 'r')
    line = test_fp.readline()
    while line != '':
        line_list = line.split(',')
        uid = line_list[0]
        poi_id = line_list[3]
        # get the user object index in the user_index_dic
        user_index = user_index_dic[uid]
        # get the user object and add poi_id to test_list of the user
        user_obj_list[user_index].add_poi_to_test_list(poi_id)
        line = test_fp.readline()
    test_fp.close()
    print "get all users test records"
    
    ##  get user topic_pref_list
    user_topic_dist_fp = open(user_topic_dist_path, 'r')
    line = user_topic_dist_fp.readline()
    while line != '':
        line = line.strip('\n')
        #delete the '' in the end
        line_list = line.split(',')
        uid = line_list[0]
        topic_pref_list = line_list[1:]
        user_index = user_index_dic[uid]
        user_obj = user_obj_list[user_index]
        user_obj.set_topic_pref_list(topic_pref_list)
        line = user_topic_dist_fp.readline()
    user_topic_dist_fp.close()
    print "get user topic_pref_list"    
    
    ## get the user pr_topic_list
    tspr_fp = open(tspr_read_path, 'r')
    line = tspr_fp.readline()
    while line != '':
        line = line.strip('\n')
        #delete the '' in the end
        line_list = line.split(',')
        uid = line_list[0]
        pr_topic_list = line_list[1:]
        user_index = user_index_dic[uid]
        user_obj = user_obj_list[user_index]
        user_obj.set_pr_topic_list(pr_topic_list)
        line = tspr_fp.readline()
    tspr_fp.close()
    print "get user pr_topic_list"
    
    ### the core idea of the experts finding
    ## get set pr value of others based on self
    for i in range(0, test_num):
        user_obj = user_obj_list[i]
        uid = user_obj.get_uid()
        topic_pref_list = user_obj.get_topic_pref_list()
        for user_obj2 in user_obj_list:
            pr_other = 0.0
            uid2 = user_obj2.get_uid()
            if user_obj.isEqual(user_obj2):
                continue
            else:
                pr_topic_list = user_obj2.get_pr_topic_list()
                for i in range(0, int(topic_num)):
                    pr_other += float(topic_pref_list[i]) * float(pr_topic_list[i])
                user_obj.add_other_pr_to_dic(uid2, pr_other)
    print "get pr value of others based on self"

    ## get the recommendation list for every user
    # get poi cadidates (all poi) to recommend
    poi_cadidates_list = get_all_poi_train_list(train_read_path)
    for i in range(0, test_num):
        print i
        user_obj = user_obj_list[i]
        other_pr_dic = user_obj.get_other_pr_dic()
        user_rec_dic = {}
        for poi_cad_id in poi_cadidates_list:
            score = 0.0
            for user_obj2 in user_obj_list:
                uid2 = user_obj2.get_uid()
                if user_obj.isEqual(user_obj2):
                    continue
                other_pr = other_pr_dic[uid2]
                other_w_of_poi = float(user_obj2.get_w_of_poi(poi_cad_id))
                score += other_pr * other_w_of_poi
            user_rec_dic[poi_cad_id] = score
        # [(poi_id,socre),...]
        top_rec_poi_s_list = sorted(user_rec_dic.items(), key = lambda x:x[1], reverse = True)[0:100]
        # [poi1, poi2, ...]        
        top_rec_poi_list = [poi_s[0] for poi_s in top_rec_poi_s_list]
        # set the poi_rec_list for the user
        user_obj.set_rec_list(top_rec_poi_list)
    print "get recommend list for all users"
    
    ## save the recommended poi of each user
    rec_fp = open(rec_list_path, 'w')
    for i in range(0, test_num):
        user_obj = user_obj_list[i]
        user_rec_list = user_obj.get_rec_list()
        uid = user_obj.get_uid()
        line = uid + ',' + ','.join(user_rec_list) + '\n'
        rec_fp.write(line)
    rec_fp.close()
    print "write the recommend list for all users"    
    
    
test_num = 2171
# foursquare1: la 514, ny: 2310, sf: 725
#gowalla: la 1279, ny 2171, sf 2531

def main():
    '''TSPR_based recommendation; Return result_tspr_city.txt file'''
    
    
    #root = 'foursquare_'
    root = 'gowalla_'
    folder = 'ny'
    city = 'ny'
    
    print "=========\n" + root + folder, test_num, "tspr_minus rec running \n========="
    
    topic_num = '15'
    read_write_dir = 'C:/Users/GuoQing/Desktop/data/' + root + folder
    train_read_path = read_write_dir + '/train_' + city + '.txt'
    test_read_path = read_write_dir + '/test_' + city + '.txt'
    
    # modify!!!
    tspr_read_path = read_write_dir + '/tspr_' +topic_num + '_minus_' + city +'.txt'
    user_topic_dist_path = read_write_dir + '/user_topic_' +topic_num + '_dist_' + city + '.txt'
    
    # modify !!!
    result_path = read_write_dir + '/result_tspr_' +topic_num + '_minus_' + city + '.txt'
    rec_list_path = read_write_dir + '/rec_list_tspr_' +topic_num + '_minus_' + city + '.txt'
    tspr_rec(read_write_dir, train_read_path, test_read_path, user_topic_dist_path, tspr_read_path, result_path, rec_list_path, topic_num)
    
    
    print "===" + root + folder + " tspr_minus rec over===", test_num
    
    
if __name__ == '__main__':
    main()