# -*- coding: utf-8 -*-
"""
Created on Sat Nov 15 12:44:17 2014

This script is to get spatial influence

@author: guoqing
"""
from math import pi, sqrt, cos, sin, asin, acos, ceil, log, floor
import matplotlib.pyplot as plt
from regression import *
from matplotlib.ticker import MultipleLocator, FuncFormatter
from matplotlib import *

class user:
    def __init__(self, uid = None):
        self.uid = uid
        self.poi_list = []
        self.home = None
    
    def get_uid(self):
        return self.uid   
    
    def add_poi_to_list(self, poi_id):
        '''This function is to add a poi to a poi_list'''
        
        # if poi_id is not in poi_list, is new; otherwise, ignore
        if poi_id not in self.poi_list:
            self.poi_list.append(poi_id) 
    
    def get_poi_list(self):
        '''get poi list of this user'''
        
        return self.poi_list
    
    def set_home(self, home):
        '''set user's home'''
        
        self.home = home
        
    def get_home(self):
        return self.home
    
    def isEqual(self, user2):
        '''This function is to tell if self and user2 are the same user'''
        
        if self.get_uid() == user2.get_uid():
            return True
        return False


def compute_geodist(lat1, lon1, lat2, lon2):
    rad_lat1 = lat1*pi/180.0
    rad_lat2 = lat2*pi/180.0
    phi = rad_lat1 - rad_lat2
    lambdaa = lon1*pi/180.0 - lon2*pi/180.0
    u = sin(phi/2.0)
    v = sin(lambdaa/2.0)
    s = 2*asin(sqrt(u * u + cos(rad_lat1) * cos(rad_lat2) * v * v))
    return s * 6378.137
    

def get_distance_common_ratio_relation(read_write_dir, train_read_path, home_path, city):
    '''This function is to get the distance of home and 
        the common ration of two users'''
        
    # get all the users
    train_fp = open(train_read_path, 'r')
    # list to store all user objects
    user_obj_list = []
    # record the index of a user in user_obj_list
    user_index_dic = {}
    i = -1
    # get the poi and its w of each user
    line = train_fp.readline()
    while line != '':
        line = line.strip('\n')
        line_list = line.split(',')
        uid = line_list[0]
        poi_id = line_list[3]
        #a new user come
        if uid not in user_index_dic:
            i += 1
            #set her index in user_index_dic
            user_index_dic[uid] = i
            # notice "userRec"
            user_obj = user(uid)
            #add the poi to poi_list of a user
            user_obj.add_poi_to_list(poi_id)
            #append her to the list
            user_obj_list.append(user_obj)
        #the user is already existing
        else:
            #get her index in the list
            user_index = user_index_dic[uid]
            #add the poi to her visited poi list
            user_obj_list[user_index].add_poi_to_list(poi_id)
        line = train_fp.readline()
    train_fp.close()
    print "get all the users poi_list"
    
    ## get homes of users
    home_fp = open(home_path, 'r')
    line = home_fp.readline()
    while line != '':
        line = line.strip('\n')
        line_list = line.split(',')
        uid = line_list[0]
        (lat, lon) = (line_list[1], line_list[2])
        user_index = user_index_dic[uid]
        user_obj = user_obj_list[user_index]
        user_obj.set_home((lat, lon))
        line = home_fp.readline()
    home_fp.close()
    print "get all users homes"
    
    ## get the relation of home distance and common poi ratio of users
    distance_aver_ratio_dic = {}
    distance_ratio_sum_dic = {}
    distance_num_dic = {}
    i = 0
    for user_obj in user_obj_list:
        i+=1; print i
        if i> 100: break
        home = user_obj.get_home()
        lat = float(home[0]); lon = float(home[1])
        poi_set = set(user_obj.get_poi_list())
        for user_obj2 in user_obj_list:
            if user_obj.isEqual(user_obj2):
                continue
            else:
                home2 = user_obj2.get_home()
                lat2 = float(home2[0]); lon2 = float(home2[1])
                geo_dist = compute_geodist(lat, lon, lat2, lon2)
                '''
                # sg:1 i=100
                round_num = 1
                distance = round(geo_dist, round_num)
                
                # ny: 2
                granularity = 20
                distance = ceil(geo_dist)
                distance = floor(distance/granularity) * granularity + granularity
                '''
                
                #print distance
                if distance not in distance_num_dic:
                    distance_num_dic[distance] = 1
                else:
                    distance_num_dic[distance] += 1
                poi_set2 = set(user_obj2.get_poi_list())
                ratio = float(len(poi_set.intersection(poi_set2))) / len(poi_set.union(poi_set2))
                #print ratio
                if distance not in distance_ratio_sum_dic:
                    distance_ratio_sum_dic[distance] = ratio
                else:
                    distance_ratio_sum_dic[distance] += ratio
    distance_ratio_log_dic = {}
    for distance in distance_ratio_sum_dic:
        if distance * distance_ratio_sum_dic[distance]==0.0:
            continue
        distance_ratio_sum = float(distance_ratio_sum_dic[distance])
        distance_num = distance_num_dic[distance]
        distance_aver_ratio_dic[distance] = distance_ratio_sum / distance_num
        #ratio_list.append(log(distance_aver_ratio_dic[distance], 10))
        aver_ratio = distance_aver_ratio_dic[distance]
        # transfer to log scale
        distance_log = math.log(distance, 10)
        distance_log = distance
        #print distance_log
        aver_ratio_log = math.log(aver_ratio, 10)
        aver_ratio_log = aver_ratio
        if distance_log not in distance_ratio_log_dic:
            distance_ratio_log_dic[distance_log] = aver_ratio_log
    distance_ratio_log_sort = sorted(distance_ratio_log_dic.items(), key = lambda x:x[0])
    distance_list = [item[0] for item in distance_ratio_log_sort]
    ratio_list = [item[1] for item in distance_ratio_log_sort]
    print "get distance_aver_ratio_dic"
    
    # draw the scatter plot
    plt.figure(figsize=(10,8), dpi=98)
    p1 = plt.subplot(111)
    #p1.scatter(distance_list, ratio_list, s = 20, marker = 'o')
    p1.plot(distance_list, ratio_list)
    ax = plt.gca()
    #ax.xaxis.set_minor_locator( MultipleLocator(0.5/20) )
    p1.set_ylabel("Commom ratio (log)",fontsize=14)
    p1.set_xlabel("Distances between homes (km log)",fontsize=14)
    #p1.set_title("Distances between homes (km log)",fontsize=14, loc='bottom')
    
    ## write the distance and ratio to a file
    distance_ratio_write_path = read_write_dir + '/distance_ratio' + city + '.txt'
    distance_ratio_write_fp = open(distance_ratio_write_path, 'w')
    for distance in distance_ratio_log_dic:
        line = '1.0' + '\t' + str(distance) + '\t' + str(distance_ratio_log_dic[distance]) + '\n'
        distance_ratio_write_fp.write(line)
    distance_ratio_write_fp.close()
    print "write distance and ratio to the file"
    
    ## get to know the power law parameters         
    distance_ratio_load_path = distance_ratio_write_path  
    xArr, yArr = loadDataSet(distance_ratio_load_path)
    xMat = mat(xArr); yMat=mat(yArr).T
    w = ridgeRegres(xMat, yMat, 0.5)
    w0 = w[0,0]
    w1 = w[1,0]
    print w0, w1
    
    
def main():
    folder = 'ny'
    city = 'ny'
    read_write_dir = 'C:/Users/GuoQing/Desktop/data/foursquare_' + folder
    train_read_path = read_write_dir + '/train_' +city + '.txt'
    home_path = read_write_dir + '/user_home_' + city + '.txt'
    get_distance_common_ratio_relation(read_write_dir, train_read_path, home_path, city)
    print "===over==="
    
    
if __name__ == '__main__':
    main()
