# -*- coding: utf-8 -*-
"""
Created on Sat Nov 08 15:08:43 2014

This script is to implement location-based collaborative filtering algorithm

@author: guoqing
"""



class userRec:
    '''This class is to describe a user's profile in the train set
        and it's used for implementing location-based cf'''
    
    def __init__(self, uid = None):
        self.uid = uid
        self.poi_test_list = []
        self.poi_rec_list = []
    
    def get_uid(self):
        return self.uid
     
    def add_poi_to_test_list(self, poi_id):
        '''This function is to add a poi to a user's poi_test_list'''
        
        if poi_id not in self.poi_test_list:
            self.poi_test_list.append(poi_id)
    
    def get_poi_test_list(self):
        '''This function is to get the poi_test_list of the user'''
        
        return self.poi_test_list
        
    def set_rec_list(self, poi_rec_list):
        '''This function is to set a user's poi_rec_list'''
        
        self.poi_rec_list = poi_rec_list
    
    def get_poi_rec_list(self):
        '''This function is to get the poi_rec_list of the user'''
        
        return self.poi_rec_list


class poiRec:
    '''This class is to describe a user's profile in the train set
        and it's used for implementing user-based cf'''
    
    def __init__(self, poi_id = None):
        self.poi_id = poi_id
        self.user_w_dic = {}
    
    def get_poi_id(self):
        return self.poi_id
    
    def add_user_w_to_dic(self, uid, w):
        '''This function is to add a poi and its w to poi_w_dic'''
        
        if uid not in self.user_w_dic:
            self.user_w_dic[uid] = w
    
    def get_user_w_dic(self):
        '''This function is to get the poi_w_dic of a user'''
        
        return self.user_w_dic
        
    def get_user_w(self, uid):
        '''This function is to get the w of a poi of a user'''
        
        user_w_dic = self.get_user_w_dic()
        if uid not in user_w_dic:
            return 0.0
        return self.user_w_dic[uid]
    
    def isEqual(self, poi2):
        '''This function is to tell if self and user2 are the same user'''
        
        if self.get_poi_id() == poi2.get_poi_id():
            return True
        return False


def get_cos_sim(poi1, poi2):
    '''This function is to get the cosine similarity given two user objects'''
    
    # 除数 divider， 被除数 upper
    cos_sim = 0.0; upper = 0.0; divider = 0.0
    poi1_user_w_dic = poi1.get_user_w_dic()
    poi2_user_w_dic = poi2.get_user_w_dic()
    # get upper
    for uid in poi1_user_w_dic:
        # if user2 also visited poi
        if uid in poi2_user_w_dic:
            upper += float(poi1_user_w_dic[uid]) * float(poi2_user_w_dic[uid])
    # get divider
    w_square_sum1 = 0.0
    for uid in poi1_user_w_dic:
        w_square_sum1 += float(poi1_user_w_dic[uid]) ** 2
    w_square_sum2 = 0.0
    for uid in poi2_user_w_dic:
        w_square_sum2 += float(poi2_user_w_dic[uid]) ** 2
    divider = (w_square_sum1 ** 0.5) * (w_square_sum2 ** 0.5)
    # get the similarity
    cos_sim = upper/divider
    return cos_sim


def lcf(read_write_dir, train_read_path, test_read_path, result_path, rec_list_path):
    '''This function is to implement user-based cf in the train set'''
    
    train_fp = open(train_read_path, 'r')
    test_fp = open(test_read_path, 'r')
    # list to store all poi objects
    poi_obj_list = []
    # record the index of a poi in poi_obj_list
    poi_index_dic = {}
    # list to store all user objects
    user_obj_list = []
    # record the index of a user in user_obj_list
    user_index_dic = {}
    i = j = -1
    # get the poi and its w of each user
    line = train_fp.readline()
    while line != '':
        line = line.strip('\n')
        line_list = line.split(',')
        uid = line_list[0]
        poi_id = line_list[3]
        w = line_list[4]
        #a new poi come
        if poi_id not in poi_index_dic:
            i += 1
            # set the poi index in poi_index_dic
            poi_index_dic[poi_id] = i
            # notice "poiRec"
            poi_obj = poiRec(poi_id)
            # add the user to user_w_dic of a poi
            poi_obj.add_user_w_to_dic(uid, w)
            # append the poi to the list
            poi_obj_list.append(poi_obj)
        # the poi is already in the list 
        else:
            # get poi index in the list
            poi_index = poi_index_dic[poi_id]
            # add the user to the user_w_dic of the poi
            poi_obj_list[poi_index].add_user_w_to_dic(uid, w)
        #a new user come
        if uid not in user_index_dic:
            j += 1
            #set her index in user_index_dic
            user_index_dic[uid] = j
            # notice "userRec"
            user_obj = userRec(uid)
            #append her to the list
            user_obj_list.append(user_obj)
        line = train_fp.readline()
    train_fp.close()
    print "get all the poi abd users in train records"
    # then get the poi test list of users
    line = test_fp.readline()
    while line != '':
        line_list = line.split(',')
        uid = line_list[0]
        poi_id = line_list[3]
        # get the user object index in the user_index_dic
        user_index = user_index_dic[uid]
        # get the user object and add poi_id to test_list of the user
        user_obj_list[user_index].add_poi_to_test_list(poi_id)
        line = test_fp.readline()
    test_fp.close()
    print "get all users test records"
    
    # get the recommendation list for every user
    # poi cadidates (all poi) to recommend : poi_obj_list
    #for user_obj in user_obj_list:
    for i in range(0, test_num):
        print i
        user_obj = user_obj_list[i]
        uid = user_obj.get_uid()
        user_rec_dic = {}
        for poi_obj in poi_obj_list:
            poi_cad_id = poi_obj.get_poi_id()
            cos_sim_sum = 0.0
            score = 0.0
            for sim_poi_obj in poi_obj_list:
                if sim_poi_obj.get_user_w(uid) == 0.0 or poi_obj.isEqual(sim_poi_obj):
                    continue
                else:
                    cos_sim = get_cos_sim(poi_obj, sim_poi_obj)
                    cos_sim_sum += cos_sim
                    score += cos_sim * float(sim_poi_obj.get_user_w(uid))
            user_rec_dic[poi_cad_id] = score
        # [(poi_id,socre),...]
        top_rec_poi_s_list = sorted(user_rec_dic.items(), key = lambda x:x[1], reverse = True)[0:100]
        # [poi1, poi2, ...]        
        top_rec_poi_list = [poi_s[0] for poi_s in top_rec_poi_s_list]
        # set the poi_rec_list for the user
        user_obj.set_rec_list(top_rec_poi_list)
    print "get recommend list for all users"
    
    # write the recommendation list of each user
    rec_fp = open(rec_list_path, 'w')
    for user_obj in user_obj_list:
        user_rec_list = user_obj.get_poi_rec_list()
        uid = user_obj.get_uid()
        line = uid + ',' + ','.join(user_rec_list) + '\n'
        rec_fp.write(line)
    rec_fp.close()
    print "write the recommend list for all users"     
    
    
test_num = 2310
# foursquare2: la 554, ny 2885, sf: 806
# foursquare1: la 514, ny: 2310, sf: 725
# gowalla: la 1279, ny 2171, sf 2531


def main():
    '''Location_based collaborative filtering
       return result_lcf file'''
       
    root = 'foursquare_'
    folder = 'ny1'
    city = 'ny'
    
    print "=========\n" + root + folder, test_num, "lcf running \n========="
    
    read_write_dir = 'C:/Users/GuoQing/Desktop/data/' + root + folder
    train_read_path = read_write_dir + '/train_' + city + '.txt'
    test_read_path = read_write_dir + '/test_' + city + '.txt'
    result_path = read_write_dir + '/result_lcf_' + city + '.txt'
    rec_list_path = read_write_dir + '/rec_list_lcf_' + city + '.txt'
    lcf(read_write_dir, train_read_path, test_read_path, result_path, rec_list_path)
    
    print "===" + root + folder + " lcf over===", test_num
    
    
if __name__ == '__main__':
    main()