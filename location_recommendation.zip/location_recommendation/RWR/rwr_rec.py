# -*- coding: utf-8 -*-
"""
Created on Wed Mar 04 14:17:48 2015

@author: I314279
"""

from get_ppr import pagerank
from pygraph.classes.graph import graph
import os

class user:
    '''This class is to describe a user's profile in the train set
        and it's used for implementing user-based cf'''
    
    def __init__(self, uid = None):
        self.uid = uid
        self.poi_w_dic = {}
        self.poi_test_list = []
        self.poi_rec_list = []
        self.place_friend_sim_dic = {}
        self.place_friend_list = []
        
    def get_uid(self):
        return self.uid
    
    def add_poi_w_to_dic(self, poi_id, w):
        '''This function is to add a poi and its w to poi_w_dic'''
        
        if poi_id not in self.poi_w_dic:
            self.poi_w_dic[poi_id] = w
    
    def get_poi_w_dic(self):
        '''This function is to get the poi_w_dic of a user'''
        
        return self.poi_w_dic
        
    def get_w_of_poi(self, poi_id):
        '''This function is to get the w of a poi of a user'''
        
        poi_w_dic = self.get_poi_w_dic()
        if poi_id not in poi_w_dic:
            return 0.0
        return poi_w_dic[poi_id]    
    
    def isEqual(self, user2):
        '''This function is to tell if self and user2 are the same user'''
        
        if self.get_uid == user2.get_uid:
            return True
        return False
        
    def add_user_to_place_friend_list(self, uid):
        '''add a place friend to the list'''
        
        self.place_friend_list.append(uid)
    
    def get_place_friend_list(self):
        return self.place_friend_list
        
    def get_place_friend_num(self):
        return len(self.get_place_friend_list())
    
    def set_place_friend_sim_dic(self, place_friend_sim_dic):
        self.place_friend_sim_dic = place_friend_sim_dic
    
    def get_place_friend_sim_dic(self):
        return self.place_friend_sim_dic


def normal(dic):
    '''This funtion is for normalization'''
    
    sum0 = 0.0
    for key in dic:
        value = dic[key]
        sum0 += value
    
    for key in dic:
        dic[key] = dic[key] / sum0
    
    return dic


def get_cos_sim(user1, user2):
    '''This function is to get the cosine similarity given two user objects'''
    
    # ?? divider, ??? upper
    cos_sim = 0.0; upper = 0.0; 
    divider = 0.0
    user1_poi_w_t_dic = user1.get_poi_w_dic()
    user2_poi_w_t_dic = user2.get_poi_w_dic()
    # get upper
    for poi_id in user1_poi_w_t_dic:
        # if user2 also visited poi
        if poi_id in user2_poi_w_t_dic:
            upper += (float(user1_poi_w_t_dic[poi_id]) * float(user2_poi_w_t_dic[poi_id]))
    # get divider
    w_square_sum1 = 0.0
    for poi_id in user1_poi_w_t_dic:
        w_square_sum1 += float(user1_poi_w_t_dic[poi_id]) ** 2
    w_square_sum2 = 0.0
    for poi_id in user2_poi_w_t_dic:
        w_square_sum2 += float(user2_poi_w_t_dic[poi_id]) ** 2
    divider = (w_square_sum1 ** 0.5) * (w_square_sum2 ** 0.5)
    # get the similarity
    cos_sim = upper / divider
    return cos_sim


def get_all_poi(train_read_path):
    '''this function is to get all the locations from the train set
    return as a list'''

    poi_list = []
    train_fp = open(train_read_path, 'r')
    line = train_fp.readline()
    while line != '':
        line = line.strip('\n')
        line_list = line.split(',')
        poi_id = 'L' + line_list[3]  # to differentiate user_id and loc_id
        if poi_id not in poi_list:
            poi_list.append(poi_id)
        line = train_fp.readline()
    train_fp.close()
    
    return poi_list
    

def get_node_edge(train_read_path):
    '''this funtion is to get normalized edge weight'''
    
    train_fp = open(train_read_path, 'r')
    # list to store all user objects
    user_obj_list = []
    # record the index of a user in user_obj_list
    user_index_dic = {}
    i = -1
    # get the poi and its w of each user
    line = train_fp.readline()
    while line != '':
        line = line.strip('\n')
        line_list = line.split(',')
        uid = line_list[0]
        poi_id = 'L' + line_list[3]  # to differentiate user_id and loc_id
        w = line_list[4]
        #a new user come
        if uid not in user_index_dic:
            i += 1
            #set her index in user_index_dic
            user_index_dic[uid] = i
            # notice "userRec"
            user_obj = user(uid)
            #add the poi to poi_w_dic of a user
            user_obj.add_poi_w_to_dic(poi_id, w)
            #append her to the list
            user_obj_list.append(user_obj)
        #the user is already existing
        else:
            #get her index in the list
            user_index = user_index_dic[uid]
            #add the poi to her visited poi list
            user_obj_list[user_index].add_poi_w_to_dic(poi_id, w)
        line = train_fp.readline()
    train_fp.close()
    print "get all the users train records"
    
    # get the place friend of each user
    for user_obj1 in user_obj_list:
        uid1 = user_obj1.get_uid()
        poi_w_dic1 = user_obj1.get_poi_w_dic()
        poi_list1 = [key for key in poi_w_dic1.keys()]
        poi_set1 = set(poi_list1)
        
        for user_obj2 in user_obj_list:
            uid2 = user_obj2.get_uid()
            if uid1 == uid2:
                continue
            else:
                poi_w_dic2 = user_obj2.get_poi_w_dic()
                poi_list2 = [key for key in poi_w_dic2.keys()]
                poi_set2 = set(poi_list2)
                if len(poi_set1.intersection(poi_set2)) > 0:
                    user_obj1.add_user_to_place_friend_list(uid2)
    print "get all the place friend of each user"    
    
    # set the link similarity between two place friends
    for user_obj1 in user_obj_list:
        uid1 = user_obj1.get_uid()
        place_friend_list = user_obj1.get_place_friend_list()
        user_sim_dic = {}
        for place_friend in place_friend_list:
            user2_index = user_index_dic[place_friend]
            user_obj2 = user_obj_list[user2_index]
            weight = get_cos_sim(user_obj1, user_obj2)
            user_sim_dic[place_friend] = weight
        if not user_sim_dic == {}:
            user_sim_norm_dic = normal(user_sim_dic)
        user_obj1.set_place_friend_sim_dic(user_sim_norm_dic)
    print "get link similarity"
    
    return user_obj_list


def prepare_G(train_read_path, test_num):
    '''This function is to create a graph object'''
    
    user_obj_list = get_node_edge(train_read_path)
    print "get user and their place friend with weight"    
        
    #construct the undirected graph 
    DG = graph()
    for user_obj1 in user_obj_list:
        uid1 = user_obj1.get_uid()
        poi_w_dic = user_obj1.get_poi_w_dic()
        if not DG.has_node(uid1):
            DG.add_node(uid1)
        # add poi node
        for poi in poi_w_dic:
            w = float(poi_w_dic[poi])
            if not DG.has_node(poi):
                DG.add_node(poi)
            if not DG.has_edge((uid1, poi)):
                DG.add_edge((uid1, poi), w)
        place_friend_sim_dic = user_obj1.get_place_friend_sim_dic()
        for place_friend in place_friend_sim_dic:
            if not DG.has_node(place_friend):
                DG.add_node(place_friend)
            weight = place_friend_sim_dic[place_friend]
            if not DG.has_edge((uid1, place_friend)):
                DG.add_edge((uid1, place_friend), weight) #undirected graph
    return DG


def rwr_rec(read_write_dir, train_read_path, city, rec_list_path, test_num):
    '''This function is to recommend by rwr'''
    
    poi_list = get_all_poi(train_read_path)
    DG = prepare_G(train_read_path, test_num)
    print "get DG"
    
    personalization = {}
    node_list = DG.nodes()
    for node in node_list:
        personalization.setdefault(node, 0.0)
        
    #start to recommend
    rec_fp = open(rec_list_path, 'w')
    i = 0
    for node1 in node_list:
        if node1 in poi_list:
            continue
        
        rec_dic  = {}
        personalization[node1] = 1.0
        node_pr_dic = pagerank(DG, personalization=personalization)
        personalization[node1] = 0.0
        for node2 in node_pr_dic:
            if node2 not in poi_list:
                continue
            node3 = node2[1:] # remove 'L'
            rec_dic.setdefault(node3, node_pr_dic[node2])
            top_rec_poi_s_list = sorted(rec_dic.items(), key = lambda x:x[1], reverse = True)[0:100]
            # [poi1, poi2, ...]        
            top_rec_poi_list = [poi_s[0] for poi_s in top_rec_poi_s_list]
        #save the recommended poi of each user
        line = node1 + ',' + ','.join(top_rec_poi_list) + '\n'
        rec_fp.close()
        print line
        i+=1
        print i, node1, '\n'
    
    rec_fp.close()
    print "write the recommend list for all users"


gow_usernum_dic = {'la':1279, 'ny': 2171, 'sf': 2531}

def main():
    '''this script is to get personal pagerank'''
    
    root = 'gowalla_'
    folder = 'la'
    city = 'la'
    test_num = gow_usernum_dic[city]
    
    print "=========\n" + root + folder, test_num, "get rwr rec running \n========="
    
    root0 = 'C:\\Users\\I314279\\GQ\\data'
    read_write_dir = os.path.join(root0, root + folder)
    train_read_path = os.path.join(read_write_dir, 'train_' + city + '.txt')    
    rec_list_path = os.path.join(read_write_dir, 'rec_list_rwr_' + city + '.txt')
    rwr_rec(read_write_dir, train_read_path, city, rec_list_path, test_num)
            
    print "===" + root + folder + " get rwr rec over===", test_num
    
    
if __name__ == '__main__':
    main()
    