# -*- coding: utf-8 -*-
"""
Created on Sat Nov 08 14:12:26 2014

@author: guoqing
"""
from linecache import getline
import matplotlib.pyplot as plt
'''
data_path = 'C:/Users/GuoQing/Desktop/data/foursquare_sg/topic_poi_dist.txt'
fp = open(data_path, 'r')
line = fp.readline()
line = line.strip('\n')

#print getline(data_path,103267).strip('\n')[1:].split(' ')
fp.close()

number_list = line.split(',')
#print number_list
fp.close()
total = 0
i = 0
print len(number_list)
for num in number_list[1:]:
    i += 1
    print i, num
    num2 = num.split('|')[1]
    #try:
     #   print float(num)
    #except:
     #   print num
    total += float(num2)
print total


rec = set( ['871', '1883', '3970', '2614', '2113', '5137', 
'38', '2419', '486', '1251', '179', '5101', '4919', 
'4505', '5162', '3170', '1500', '3972', '1077', '4868', 
'23', '5591', '3213', '3837', '3041', '224', '1352', '123', 
'4092', '5335', '4221', '2381', '1433', '1960', '1238',
 '4733', '266', '922', '4162', '1441', '732', '312', '2665', 
 '613', '4309', '1392', '4786', '5403', '3971', '4834', '927',
 '4858', '2299', '415', '4996', '134', '981', '1748', '4340', '4883',
 '2505', '3597', '3122', '4585', '5423', '1048', '872', '1974', '4702', 
 '4966', '4742', '4633', '2748', '1779', '1079', '5205', '1775', '4728', 
 '1144', '798', '231', '3862', '1592', '1842', '4979', '5221', '2148',
 '5003', '2780', '4393', '2048', '5377', '3346', '2909', '554', '966', '4254', '721', '4922', '4957'])
test =  set(['1392', '38', '1601', '1779', '1347', '123', '723', '3170', '5491', '2148'])

print len(rec.intersection(test))


x = [1,2, 3]
y = [2,3,4]
plt.scatter(x, y)
'''

#!/usr/bin/env python
'''
import numpy as np
import matplotlib.pyplot as plt

def f1(t):
    return np.exp(-t)*np.cos(2*np.pi*t)

def f2(t):
    return np.sin(2*np.pi*t)*np.cos(3*np.pi*t)

t = np.arange(0.0,5.0,0.02)

plt.figure(figsize=(8,7),dpi=98)
p1 = plt.subplot(211)
p2 = plt.subplot(212)

label_f1 = "$f(t)=e^{-t} \cos (2 \pi t)$"
label_f2 = "$g(t)=\sin (2 \pi t) \cos (3 \pi t)$"

p1.plot(t,f1(t),"g-",label=label_f1)
p2.plot(t,f2(t),"r-.",label=label_f2,linewidth=2)

p1.axis([0.0,5.01,-1.0,1.5])

p1.set_ylabel("v",fontsize=14)
p1.set_title("A simple example",fontsize=18)
p1.grid(True)
#p1.legend()

tx = 2
ty = 0.9
p1.text(tx,ty,label_f1,fontsize=15,verticalalignment="top",horizontalalignment="right")

p2.axis([0.0,5.01,-1.0,1.5])
p2.set_ylabel("v",fontsize=14)
p2.set_xlabel("t",fontsize=14)
#p2.legend()
tx = 2
ty = 0.9
p2.text(tx,ty,label_f2,fontsize=15,verticalalignment="bottom",horizontalalignment="left")

p2.annotate('',xy=(1.8,0.5),xytext=(tx,ty),arrowprops=dict(arrowstyle="->",connectionstyle="arc3"))

plt.show()
'''

import numpy as np
'''
class Distribution(object):
    """
    draws samples from a one dimensional probability distribution,
    by means of inversion of a discrete inverstion of a cumulative density function

    the pdf can be sorted first to prevent numerical error in the cumulative sum
    this is set as default; for big density functions with high contrast,
    it is absolutely necessary, and for small density functions,
    the overhead is minimal

    a call to this distibution object returns indices into density array
    """
    def __init__(self, pdf, sort = True, interpolation = True, transform = lambda x: x):
        self.shape          = pdf.shape
        self.pdf            = pdf.ravel()
        self.sort           = sort
        self.interpolation  = interpolation
        self.transform      = transform

        #a pdf can not be negative
        assert(np.all(pdf>=0))

        #sort the pdf by magnitude
        if self.sort:
            self.sortindex = np.argsort(self.pdf, axis=None)
            self.pdf = self.pdf[self.sortindex]
        #construct the cumulative distribution function
        self.cdf = np.cumsum(self.pdf)
    @property
    def ndim(self):
        return len(self.shape)
    @property
    def sum(self):
        """cached sum of all pdf values; the pdf need not sum to one, and is imlpicitly normalized"""
        return self.cdf[-1]
    def __call__(self, N):
        """draw """
        #pick numbers which are uniformly random over the cumulative distribution function
        choice = np.random.uniform(high = self.sum, size = N)
        #find the indices corresponding to this point on the CDF
        index = np.searchsorted(self.cdf, choice)
        #if necessary, map the indices back to their original ordering
        if self.sort:
            index = self.sortindex[index]
        #map back to multi-dimensional indexing
        index = np.unravel_index(index, self.shape)
        index = np.vstack(index)
        #is this a discrete or piecewise continuous distribution?
        if self.interpolation:
            index = index + np.random.uniform(size=index.shape)
        return self.transform(index)

if __name__=='__main__':
    shape = 3,3
    pdf = np.ones(shape)
    pdf[1]=0
    dist = Distribution(pdf, transform=lambda i:i-1.5)
    print dist(10)
    import matplotlib.pyplot as pp
    pp.scatter(*dist(1000))
    pp.show()
    
x = np.linspace(-100, 100, 512)
p = np.exp(-x**2)
pdf = p[:,None]*p[None,:]     #2d gaussian
dist = Distribution(pdf, transform=lambda i:i-256)
print dist(1000000).mean(axis=1)    #should be in the 1/sqrt(1e6) range
import matplotlib.pyplot as pp
pp.scatter(*dist(1000))
pp.show()
'''

'''
from scipy import stats
import matplotlib.pyplot as plt
x1 = np.array([-7, -5, 1, 4, 5], dtype=np.float)
kde1 = stats.gaussian_kde(x1)
kde2 = stats.gaussian_kde(x1, bw_method='silverman')
fig = plt.figure()
ax = fig.add_subplot(111)
ax.plot(x1, np.zeros(x1.shape), 'b+', ms=20)  # rug plot
x_eval = np.linspace(-10, 10, num=200)
ax.plot(x_eval, kde1(x_eval), 'k-', label="Scott's Rule")
ax.plot(x_eval, kde2(x_eval), 'r-', label="Silverman's Rule")
plt.show

print kde1(0.1)[0]
'''

'''
from scipy import stats
def measure(n):
    "Measurement model, return two coupled measurements."
    m1 = np.random.normal(size=n)
    m2 = np.random.normal(scale=0.5, size=n)
    return m1+m2, m1-m2

def get_kernel(xlist, ylist):
    #m1, m2 = measure(10)
    m1 = np.array(xlist, dtype=np.float)
    m2 = np.array(ylist, dtype=np.float)
    xmin = m1.min()-5
    xmax = m1.max()+5
    ymin = m2.min()-5
    ymax = m2.max()+5

    print type(m1)
    #Perform a kernel density estimate on the data:
    
    X, Y = np.mgrid[xmin:xmax:100j, ymin:ymax:100j]
    positions = np.vstack([X.ravel(), Y.ravel()])
    values = np.vstack([m1, m2])

    kernel = stats.gaussian_kde(values)

    #Plot the results:
    
    Z = np.reshape(kernel(positions).T, X.shape)
    import matplotlib.pyplot as plt
    fig = plt.figure()
    ax = fig.add_subplot(111)
    ax.imshow(np.rot90(Z), cmap=plt.cm.gist_earth_r,
          extent=[xmin, xmax, ymin, ymax])
    ax.plot(m1, m2, 'k.', markersize=2)
    ax.set_xlim([xmin, xmax])
    ax.set_ylim([ymin, ymax])
    plt.show()
    
    return kernel


from scipy import integrate
from math import *
def main():
    #global kernel1
    #global kernel2
    xlist1 = [-7, -5, 1, 4, 5, 5,5,5,5,5,5,5,5,5]
    ylist1 = [-10, -2, 11, 4, 9, 9,9,9,9,9,9,9,9,9]
    kernel1 = get_kernel(xlist1, ylist1)
    xlist2 = [-1, -4, 10, 12, 35, 25,5,25,95,15,34,22,55,59]
    ylist2 = [-10, -23, 31, 24, 96, 23,24,0,7,4,8,6,1,19]
    kernel2 = get_kernel(xlist2, ylist2)
    print type(kernel1)
    def f(x, y):
        xx = np.array([x], dtype=np.float)
        yy = np.array([y], dtype=np.float)
        xy = np.vstack([xx, yy])
        dist = kernel1(xy)[0]
        return dist
    x1 = np.array([0.8], dtype=np.float)
    y1 = np.array([0.5], dtype=np.float)
    xy = np.vstack([x1, y1])
    #print kernel1.resample(2)
    print kernel1.integrate_kde(kernel2)
    #print kernel1.evaluate((0.1,0.9))[0]
    #print kernel1.integrate_box([-20, -20],[20, 20])
    #print kernel1.integrate_box([-100, -100],[100, 100])
    #a = integrate.nquad(f, [[float('-Inf'), float('Inf')],[float('-Inf'), float('Inf')]])
    #print a[0]
    


if __name__ == '__main__':
    main()
'''

import string

def CleanLines(line):
    identify = string.maketrans('', '')
    #print identify
    delEStr = string.punctuation +string.digits  #ASCII 标点符号，数字
    #print delEStr
    cleanLine =line.translate(identify,delEStr) #去掉ASCII 标点符号
    cleanLine = cleanLine.replace(" ","")
    cleanLine = cleanLine.lower()
    return cleanLine


def main():
    #line = 'sal/ ? BBook?12--3'
    line = 'Indian Restaurant| best indian buffet, best indian lunch buffet, catering, food delivery, indian food, indian food catering, indian food caters, kerala restaurant los angeles, take out food,appam,dosa,indian restaurant,indian restaurant best indian buffet kerala restaurant los angeles indian food best indian lunch buffet indian food catering catering indian food caters take out food food delivery,kerala|'
    new_line = CleanLines(line)
    
    print new_line


if __name__ == '__main__':
    main()














