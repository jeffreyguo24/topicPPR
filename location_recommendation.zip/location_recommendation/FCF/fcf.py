# -*- coding: utf-8 -*-
"""
Created on Fri Nov 07 15:33:12 2014

This script is to implement user-based collaborative filtering algorithm

@author: guoqing
"""

import random

class user:
    '''This class is to desribe a user's profile and it's only 
        for gettingtrain and test set'''
    
    def __init__(self, uid = None):
        self.uid = uid
        self.poi_freq_dic = {}
        self.poi_w_dic = {}
        self.poi_list = []
        self.poi_test_list = []
    
    def get_uid(self):
        return self.uid
    
    def add_poi_to_freq_dic(self, poi_id):
        '''This function is to add a poi to poi_freq_dic'''
        
        # if poi_id is not in poi_freq_dic, is new
        if poi_id not in self.poi_freq_dic:
            self.poi_freq_dic[poi_id] = 1
        # if poi_id is already in poi_freq_dic
        else:
            self.poi_freq_dic[poi_id] += 1
    
    def add_poi_to_list(self, poi_id):
        '''This function is to add a poi to a poi_list'''
        
        # if poi_id is not in poi_list, is new; otherwise, ignore
        if poi_id not in self.poi_list:
            self.poi_list.append(poi_id) 
    
    def get_poi_list(self):
        '''get poi list of this user'''
        
        return self.poi_list
    
    def get_poi_w_dic(self):
        '''poi_freq_dic --> poi_w_dic, w(u, l) = freq(u,l)/sum(freq(u, li)^2)'''
        
        freq_square_sum = 0.0
        # compute freq_square_sum
        for poi_id in self.poi_freq_dic:
            freq_square = self.poi_freq_dic[poi_id]
            freq_square_sum += freq_square
        # transfer freq --> w
        for poi_id in self.poi_freq_dic:
            freq = self.poi_freq_dic[poi_id]
            w = freq / freq_square_sum
            self.poi_w_dic[poi_id] = w
        return self.poi_w_dic

        

class userRec:
    '''This class is to describe a user's profile in the train set
        and it's used for implementing user-based cf'''
    
    def __init__(self, uid = None):
        self.uid = uid
        self.poi_w_dic = {}
        self.poi_test_list = []
        self.poi_rec_list = []
        self.friend_list = []
    
    def get_uid(self):
        return self.uid
    
    def add_poi_w_to_dic(self, poi_id, w):
        '''This function is to add a poi and its w to poi_w_dic'''
        
        if poi_id not in self.poi_w_dic:
            self.poi_w_dic[poi_id] = w
    
    def get_poi_w_dic(self):
        '''This function is to get the poi_w_dic of a user'''
        
        return self.poi_w_dic
        
    def get_w_of_poi(self, poi_id):
        '''This function is to get the w of a poi of a user'''
        
        poi_w_dic = self.get_poi_w_dic()
        if poi_id not in poi_w_dic:
            return 0.0
        return poi_w_dic[poi_id]
        
    def add_poi_to_test_list(self, poi_id):
        '''This function is to add a poi to a user's poi_test_list'''
        
        if poi_id not in self.poi_test_list:
            self.poi_test_list.append(poi_id)
    
    def get_poi_test_list(self):
        '''This function is to get the poi_test_list of the user'''
        
        return self.poi_test_list
        
    def set_rec_list(self, poi_rec_list):
        '''This function is to set a user's poi_rec_list'''
        
        self.poi_rec_list = poi_rec_list
    
    def get_poi_rec_list(self):
        '''This function is to get the poi_rec_list of the user'''
        
        return self.poi_rec_list
    
    def isEqual(self, user2):
        '''This function is to tell if self and user2 are the same user'''
        
        if self.get_uid == user2.get_uid:
            return True
        return False
    
    def set_friend_list(self, friend_list):
        '''add a friend to the friend list of the user'''
        
        self.friend_list = friend_list
        
    def get_friend_list(self):
        return self.friend_list
    

def get_cos_sim(user1, user2):
    '''This function is to get the cosine similarity given two user objects'''
    
    # 除数 divider， 被除数 upper
    cos_sim = 0.0; upper = 0.0; 
    divider = 0.0
    user1_poi_w_dic = user1.get_poi_w_dic()
    user2_poi_w_dic = user2.get_poi_w_dic()
    # get upper
    for poi_id in user1_poi_w_dic:
        # if user2 also visited poi
        if poi_id in user2_poi_w_dic:
            upper += float(user1_poi_w_dic[poi_id]) * float(user2_poi_w_dic[poi_id])
    # get divider
    w_square_sum1 = 0.0
    for poi_id in user1_poi_w_dic:
        w_square_sum1 += float(user1_poi_w_dic[poi_id]) ** 2
    w_square_sum2 = 0.0
    for poi_id in user2_poi_w_dic:
        w_square_sum2 += float(user2_poi_w_dic[poi_id]) ** 2
    divider = (w_square_sum1 ** 0.5) * (w_square_sum2 ** 0.5)
    # get the similarity
    cos_sim = upper/divider
    return cos_sim
 

def get_all_poi_train_list(train_read_path):
    '''This function is to get all the poi (candidate locations)'''
    
    poi_train_list = []
    train_fp = open(train_read_path, 'r')
    line = train_fp.readline()
    while line != '':
        line_list = line.split(',')
        poi_id = line_list[-2]
        if poi_id not in poi_train_list:
            poi_train_list.append(poi_id)
        line = train_fp.readline()
    return poi_train_list


def fcf(read_write_dir, train_read_path, test_read_path, friend_path, result_path):
    '''This function is to implement user-based cf in the train set'''
    
    train_fp = open(train_read_path, 'r')
    test_fp = open(test_read_path, 'r')
    # list to store all user objects
    user_obj_list = []
    # record the index of a user in user_obj_list
    user_index_dic = {}
    i = -1
    # get the poi and its w of each user
    line = train_fp.readline()
    while line != '':
        line = line.strip('\n')
        line_list = line.split(',')
        uid = line_list[0]
        poi_id = line_list[3]
        w = line_list[4]
        #a new user come
        if uid not in user_index_dic:
            i += 1
            #set her index in user_index_dic
            user_index_dic[uid] = i
            # notice "userRec"
            user_obj = userRec(uid)
            #add the poi to poi_w_dic of a user
            user_obj.add_poi_w_to_dic(poi_id, w)
            #append her to the list
            user_obj_list.append(user_obj)
        #the user is already existing
        else:
            #get her index in the list
            user_index = user_index_dic[uid]
            #add the poi to her visited poi list
            user_obj_list[user_index].add_poi_w_to_dic(poi_id, w)
        line = train_fp.readline()
    train_fp.close()
    print "get all the users train records"
    # then get the poi test list of users
    line = test_fp.readline()
    while line != '':
        line_list = line.split(',')
        uid = line_list[0]
        poi_id = line_list[3]
        # get the user object index in the user_index_dic
        user_index = user_index_dic[uid]
        # get the user object and add poi_id to test_list of the user
        user_obj_list[user_index].add_poi_to_test_list(poi_id)
        line = test_fp.readline()
    test_fp.close()
    print "get all users test records"
    # get the friends of all users
    friend_fp = open(friend_path, 'r')
    line = friend_fp.readline()
    while line != '':
        line = line.strip('\n')
        line_list = line.split(',')
        uid = line_list[0]
        user_index = user_index_dic[uid]
        user_obj = user_obj_list[user_index]
        if line_list[1] == '':
            friend_list = []
        else: 
            friend_list = line_list[1:]
        user_obj.set_friend_list(friend_list)
        line = friend_fp.readline()
    print "get all friends of users"
    # get the recommendation list for every user
    # get poi cadidates (all poi) to recommend
    poi_cadidates_list = get_all_poi_train_list(train_read_path)
    i = 0
    # this number is to record users who does not have friends
    missing = 0
    #for i in range(71, 80):
        #print i
    for user_obj in user_obj_list:
     #   user_obj = user_obj_list[i]
        i += 1
        print i
        user_rec_dic = {}
        # get friend_list
        friend_list = user_obj.get_friend_list()
        if len(friend_list) == 0:
            missing += 1
            continue
        for poi_cad_id in poi_cadidates_list:
            score = 0.0
            for friend_id in friend_list:
                friend_index = user_index_dic[friend_id]
                friend_obj = user_obj_list[friend_index]
                if friend_obj.get_w_of_poi(poi_cad_id) == 0.0\
                    or user_obj.isEqual(friend_obj):
                        continue
                else:
                    score += get_cos_sim(user_obj, friend_obj) * \
                    float(friend_obj.get_w_of_poi(poi_cad_id))
            user_rec_dic[poi_cad_id] = score
        # [(poi_id,socre),...]
        top_rec_poi_s_list = sorted(user_rec_dic.items(), key = lambda x:x[1], reverse = True)[0:100]
        # [poi1, poi2, ...]        
        top_rec_poi_list = [poi_s[0] for poi_s in top_rec_poi_s_list]
        # set the poi_rec_list for the user
        user_obj.set_rec_list(top_rec_poi_list)
    print "get recommend list for all users"
    # compute precision and recall
    precision_sum = [0.0 for i in range(0, 10)]
    recall_sum = [0.0 for i in range(0, 10)] 
    for user_obj in user_obj_list:
    #for i in range(71, 80):
     #   user_obj = user_obj_list[i]
        precision = [0.0 for i in range(0, 10)]
        recall = [0.0 for i in range(0, 10)]
        user_rec_list = user_obj.get_poi_rec_list()
        #print 'uid', user_obj.get_uid()
        #print "rec", user_rec_list
        user_test_set = set(user_obj.get_poi_test_list())
        #print "test", user_test_set
        user_test_poi_num = len(user_test_set)
        for j in range(0, 10):
            user_rec_set_j = set(user_rec_list[0:(j+1)*10])
            #print user_rec_set_i
            hit_num =  float(len(user_rec_set_j.intersection(user_test_set)))
            #print "hit_num", hit_num
            precision[j] = hit_num / (j*10 + 10)
            #print 'precision', precision[j]
            if user_test_poi_num == 0.0: 
                print "=====", user_obj.get_uid()
                continue
            recall[j] = hit_num / user_test_poi_num
            precision_sum[j] += precision[j]
            recall_sum[j] += recall[j]
    # save the result
    user_num = len(user_obj_list) - missing
    #user_num  = 10
    result_fp = open(result_path, 'w')
    for j in range(0, 10):
        precision_average = precision_sum[j] / user_num
        #print precision_average
        recall_average = recall_sum[j] / user_num
        #print precision_average
        line = str(j*10+10) + '\t' + '%0.5f' % (precision_average) + '\t' + \
                '%0.5f' % (recall_average) + '\n'
        result_fp.write(line)
    result_fp.close()
    
    
def main():
    '''User_based collaborative filtering
       Return result_ucf file'''
       
    folder = 'pro'
    read_write_dir = 'C:/Users/GuoQing/Desktop/data/foursquare_' + folder
    city = 'ny'
    
    train_read_path = read_write_dir + '/train_' + city + '.txt'
    test_read_path = read_write_dir + '/test_' + city + '.txt'
    friend_path = read_write_dir + '/friend_' + city + '.txt'
    result_path = read_write_dir + '/result_fcf_' + city + '.txt'
    fcf(read_write_dir, train_read_path, test_read_path, friend_path, result_path)
    print "===over==="
    
    
if __name__ == '__main__':
    main()
        
        
'''
def get_train_test_sets(read_write_dir, read_path):
    #This function is to prepare train and test sets
    
    # train file save path
    train_write_path = read_write_dir + '/train.txt'
    train_write_fp = open(train_write_path, 'w')
    #test file save path
    test_write_path  = read_write_dir + '/test.txt'
    test_write_fp = open(test_write_path, 'w')
    # poi dictionary to store poi_id, lattitude and longitude of a poi
    poi_lat_lon_dic = {}
    # user objects list
    user_obj_list = []
    #record the index of a user in user_obj_list
    user_index_dic = {}
    i = -1
    read_fp = open(read_path, 'r')
    line = read_fp.readline()
    while line != '':
        line = line.strip('\n')
        line_list = line.split(',')
        uid = line_list[0]; lat = line_list[1]
        lon = line_list[2]; poi_id = line_list[3]
        # save poi_id and it's lat and lon into a dictionary
        if poi_id not in poi_lat_lon_dic:
            poi_lat_lon_dic[poi_id] = lat + ',' + lon
        #a new user come
        if uid not in user_index_dic:
            i += 1
            #set her index in user_index_dic
            user_index_dic[uid] = i
            user_obj = user(uid)
            #add the poi to poi_id and poi_to_freq_dic
            user_obj.add_poi_to_list(poi_id)
            user_obj.add_poi_to_freq_dic(poi_id)
            #append her to the list
            user_obj_list.append(user_obj)
        #the user is already existing
        else:
            #get her index in the list
            user_index = user_index_dic[uid]
            #add the poi to her visited poi list
            user_obj_list[user_index].add_poi_to_list(poi_id)
            user_obj_list[user_index].add_poi_to_freq_dic(poi_id)
        line = read_fp.readline()
    # get train and test sets
    for user_obj in user_obj_list:
        uid = user_obj.get_uid()
        # poi_w_dic of a user
        poi_w_dic = user_obj.get_poi_w_dic()
        # get a user's visited poi_list
        poi_list = user_obj.get_poi_list()
        poi_num = len(poi_list)
        # number of poi of train set (train: test = 4:1)
        train_num = int(poi_num * 0.80 + 0.5)
        # index_list of train index in the poi_list of a user
        train_index_list = random.sample(range(0, poi_num), train_num)
        # get the train test sets
        for i in range(0, poi_num):
            poi_id = poi_list[i]
            poi_lat_lon = poi_lat_lon_dic[poi_id]
            new_line = uid + ',' + poi_lat_lon + ',' + poi_id + ',' + \
                        str(poi_w_dic[poi_id]) + '\n'
            # i is a train index of a poi in poi_list
            if i in train_index_list:
                train_write_fp.write(new_line)
            # if i is not a train index, so it's a test index in poi_list
            else: test_write_fp.write(new_line)
    train_write_fp.close()
    test_write_fp.close()
    return (train_write_path, test_write_path)
    '''       
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    