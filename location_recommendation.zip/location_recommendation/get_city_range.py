# -*- coding: utf-8 -*-

from math import *

def compute_geodist(lat1, lon1, lat2, lon2):
    rad_lat1 = lat1*pi/180.0
    rad_lat2 = lat2*pi/180.0
    phi = rad_lat1 - rad_lat2
    lambdaa = lon1*pi/180.0 - lon2*pi/180.0
    u = sin(phi/2.0)
    v = sin(lambdaa/2.0)
    s = 2*asin(sqrt(u * u + cos(rad_lat1) * cos(rad_lat2) * v * v))
    return s * 6378.137


def trans_lat_lon_to_xy(lat_center, lon_center, poi_lat, poi_lon):
    '''this function is to transfer the lat and lon to x and y'''
    
    x = compute_geodist(lat_center, lon_center, lat_center, poi_lon)
    y = compute_geodist(poi_lat, poi_lon, lat_center, poi_lon)
    
    if poi_lat>lat_center and poi_lon>lon_center:
        return (x, y)
    elif poi_lat>lat_center and poi_lon<lon_center:
        x = -x
    elif poi_lat<lat_center and poi_lon<lon_center:
        x = -x; y = -y
    elif poi_lat<lat_center and poi_lon>lon_center:
        y = -y
    return (x, y)


def get_city_range(read_path, center):
    
    read_fp = open(read_path, 'r')
    line = read_fp.readline()
    lat_xmin = 0.0; lon_ymin = 0.0
    lat_xmax = 0.0; lon_ymax = 0.0
    xmin = 0.0; ymin = 0.0
    xmax = 0.0; ymax = 0.0
    while line!='':
        line = line.strip('\n')
        line_list = line.split(',')
        lat = float(line_list[1])
        lon = float(line_list[2])
        
        xy = trans_lat_lon_to_xy(center[0], center[1], lat, lon)
        x = xy[0]; y = xy[1]
        if x<xmin:
            xmin = x
            lon_xmin = lon
        if y<ymin:
            ymin = y
            lat_ymin = lat
        if x>xmax:
            xmax = x
            lon_xmax = lon
        if y>ymax:
            ymax = y
            lat_ymax = lat
        
        line = read_fp.readline()
    read_fp.close()
    return [(xmin, ymin, xmax, ymax), (lon_xmin, lat_ymin, lon_xmax, lat_ymax)]   
    

def main():
    '''get train and test sets'''
    
    folder = 'sf'
    city = 'sf'
    center = (37.7650776726, -122.414312421)
    
    read_write_dir = 'C:/Users/GuoQing/Desktop/data/foursquare_' + folder
    read_path = read_write_dir + '/foursquare_pro_' + city + '_pro.txt'
    
    xy_range = get_city_range(read_path, center)
    print xy_range
    
    print "===over==="
    


if __name__ == '__main__':
    main()


'''
sf:
[(-8.77220343001761, -74.59896925352153, 67.5680208523093, 7.071607098644513), 
 (-122.51399517, 37.09494373, -121.64650252, 37.828603)]
 
'''