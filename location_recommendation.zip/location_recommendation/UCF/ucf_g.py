# -*- coding: utf-8 -*-
"""
Created on Wed Mar 04 11:59:14 2015

@author: I314279
"""

import os
from math import pi, sqrt, cos, sin, asin

class userRec:
    '''This class is to describe a user's profile in the train set
        and it's used for implementing user-based cf'''
    
    def __init__(self, uid = None):
        self.uid = uid
        self.poi_w_dic = {}
        self.poi_test_list = []
        self.poi_rec_list = []
        self.lat_lon_list =[]
    
    def get_uid(self):
        return self.uid
    
    def add_poi_w_to_dic(self, poi_id, w):
        '''This function is to add a poi and its w to poi_w_dic'''
        
        if poi_id not in self.poi_w_dic:
            self.poi_w_dic[poi_id] = w
    
    def get_poi_w_dic(self):
        '''This function is to get the poi_w_dic of a user'''
        
        return self.poi_w_dic
        
    def get_w_of_poi(self, poi_id):
        '''This function is to get the w of a poi of a user'''
        
        poi_w_dic = self.get_poi_w_dic()
        if poi_id not in poi_w_dic:
            return 0.0
        return poi_w_dic[poi_id]
        
    def add_poi_to_test_list(self, poi_id):
        '''This function is to add a poi to a user's poi_test_list'''
        
        if poi_id not in self.poi_test_list:
            self.poi_test_list.append(poi_id)
    
    def get_poi_test_list(self):
        '''This function is to get the poi_test_list of the user'''
        
        return self.poi_test_list
        
    def set_rec_list(self, poi_rec_list):
        '''This function is to set a user's poi_rec_list'''
        
        self.poi_rec_list = poi_rec_list
    
    def get_poi_rec_list(self):
        '''This function is to get the poi_rec_list of the user'''
        
        return self.poi_rec_list
    
    def isEqual(self, user2):
        '''This function is to tell if self and user2 are the same user'''
        
        if self.get_uid == user2.get_uid:
            return True
        return False
    
    def add_lat_lon_toList(self, lat_lon):
        if not lat_lon in self.lat_lon_list:
            self.lat_lon_list.append(lat_lon)
        else:
            pass
        
    def get_lat_lon_list(self):
        return self.lat_lon_list
    

def get_cos_sim(user1, user2):
    '''This function is to get the cosine similarity given two user objects'''
    
    # 除数 divider， 被除数 upper
    cos_sim = 0.0; upper = 0.0; 
    divider = 0.0
    user1_poi_w_dic = user1.get_poi_w_dic()
    user2_poi_w_dic = user2.get_poi_w_dic()
    # get upper
    for poi_id in user1_poi_w_dic:
        # if user2 also visited poi
        if poi_id in user2_poi_w_dic:
            upper += float(user1_poi_w_dic[poi_id]) * float(user2_poi_w_dic[poi_id])
    # get divider
    w_square_sum1 = 0.0
    for poi_id in user1_poi_w_dic:
        w_square_sum1 += float(user1_poi_w_dic[poi_id]) ** 2
    w_square_sum2 = 0.0
    for poi_id in user2_poi_w_dic:
        w_square_sum2 += float(user2_poi_w_dic[poi_id]) ** 2
    divider = (w_square_sum1 ** 0.5) * (w_square_sum2 ** 0.5)
    # get the similarity
    cos_sim = upper/divider
    return cos_sim


def normal(dic):
    '''This funtion is for normalization'''
    
    sum0 = 0.0
    for key in dic:
        value = dic[key]
        sum0 += value
    
    for key in dic:
        dic[key] = dic[key] / sum0
    
    return dic


def compute_geodist(lat_lon1, lat_lon2):
    lat1 = lat_lon1[0]; lon1 =lat_lon1[1]
    lat2 = lat_lon2[0]; lon2 =lat_lon2[1]
    rad_lat1 = lat1*pi/180.0
    rad_lat2 = lat2*pi/180.0
    phi = rad_lat1 - rad_lat2
    lambdaa = lon1*pi/180.0 - lon2*pi/180.0
    u = sin(phi/2.0)
    v = sin(lambdaa/2.0)
    s = 2*asin(sqrt(u * u + cos(rad_lat1) * cos(rad_lat2) * v * v))
    return s * 6378.137
    

def get_geo_score(user_obj, poi_lat_lon, city):
    '''this function is to compute the geographical score'''

    ab = ab_dict[city]
    a = ab[0]; b = ab[1]
    lat_lon_list = user_obj.get_lat_lon_list()
    y = 0.0 #geo_score
    for lat_lon in lat_lon_list:
        x = compute_geodist(lat_lon, poi_lat_lon)
        if x!=0.0:
            y += x**b #no need for a
    return y


def get_all_poi_train_list(train_read_path):
    '''This function is to get all the poi (candidate locations)'''
    
    poi_train_lat_lon_dict = {}
    train_fp = open(train_read_path, 'r')
    line = train_fp.readline()
    while line != '':
        line_list = line.split(',')
        lat = float(line_list[1])
        lon = float(line_list[2])
        poi_id = line_list[3]
        if poi_id not in poi_train_lat_lon_dict:
            poi_train_lat_lon_dict.setdefault(poi_id, (lat, lon))
        line = train_fp.readline()
    return poi_train_lat_lon_dict


def ucf_g(read_write_dir, train_read_path, test_read_path, result_path, rec_list_path, test_num, city):
    '''This function is to implement user-based cf in the train set'''
    
    train_fp = open(train_read_path, 'r')
    #list to store all user objects
    user_obj_list = []
    #record the index of a user in user_obj_list
    user_index_dic = {}
    i = -1
    # get the poi and its w of each user
    line = train_fp.readline()
    while line != '':
        line = line.strip('\n')
        line_list = line.split(',')
        uid = line_list[0]
        lat = float(line_list[1])
        lon = float(line_list[2])
        poi_id = line_list[3]
        w = line_list[4]
        #a new user come
        if uid not in user_index_dic:
            i += 1
            #set her index in user_index_dic
            user_index_dic[uid] = i
            # notice "userRec"
            user_obj = userRec(uid)
            #add the poi to poi_w_dic of a user
            user_obj.add_poi_w_to_dic(poi_id, w)
            #add the lat_lon of the poi a list
            user_obj.add_lat_lon_toList((lat, lon))
            #append her to the list
            user_obj_list.append(user_obj)
        #the user is already existing
        else:
            #get her index in the list
            user_index = user_index_dic[uid]
            #add the poi to her visited poi list
            user_obj_list[user_index].add_poi_w_to_dic(poi_id, w)
            user_obj.add_lat_lon_toList((lat, lon))
        line = train_fp.readline()
    train_fp.close()
    print "get all the users train records"
    
    #get the recommendation list for every user
    #get poi cadidates (all poi) to recommend
    poi_train_lat_lon_dict = get_all_poi_train_list(train_read_path)
    for i in range(0, test_num):
        print i
        user_obj = user_obj_list[i]
        user_rec_dic = {}
        poi_ucf_score_dict = {}
        poi_geo_score_dict = {}
        for poi_cad_id in poi_train_lat_lon_dict:
            #score from cf/similar users
            ucf_score = 0.0
            for user_obj2 in user_obj_list:
                if user_obj2.get_w_of_poi(poi_cad_id) == 0.0\
                    or user_obj.isEqual(user_obj2):
                        continue
                else:
                    ucf_score += get_cos_sim(user_obj, user_obj2) * \
                    float(user_obj2.get_w_of_poi(poi_cad_id))
            poi_ucf_score_dict[poi_cad_id] = ucf_score
            #score from geographical influence
            poi_lat_lon = poi_train_lat_lon_dict[poi_cad_id]
            geo_score = get_geo_score(user_obj, poi_lat_lon, city)
            poi_geo_score_dict[poi_cad_id] = geo_score
        #normalize the two score dict
        poi_normal_ucf_score_dict = normal(poi_ucf_score_dict)
        poi_normal_geo_score_dict = normal(poi_geo_score_dict)
        #combine
        for poi_cad_id in poi_normal_ucf_score_dict:
            ucf_score = poi_normal_ucf_score_dict[poi_cad_id]
            geo_score = poi_normal_geo_score_dict[poi_cad_id]
            user_rec_dic[poi_cad_id] = 0.5 * ucf_score + 0.5 * geo_score # alpha = 0.2
        # [(poi_id,socre),...]
        top_rec_poi_s_list = sorted(user_rec_dic.items(), key = lambda x:x[1], reverse = True)[0:100]
        # [poi1, poi2, ...]        
        top_rec_poi_list = [poi_s[0] for poi_s in top_rec_poi_s_list]
        # set the poi_rec_list for the user
        user_obj.set_rec_list(top_rec_poi_list)
    print "get recommend list for all users"
    
    # save recommendation list of each user
    rec_fp = open(rec_list_path, 'w')
    for user_obj in user_obj_list:
        user_rec_list = user_obj.get_poi_rec_list()
        uid = user_obj.get_uid()
        line = uid + ',' + ','.join(user_rec_list) + '\n'
        rec_fp.write(line)
    rec_fp.close()
    print "write the recommend list for all users" 
    
            
#gowalla: la 1279, ny 2171, sf: 2531
gow_usernum_dic = {'la':1279, 'ny': 2171, 'sf': 2531}
#gowalla regression parameters；
ab_dict = {'la':(283294.011009, -1.05171855134), 'ny':(6088014.89876, -2.54001500365),\
            'sf':(3190165.78723, -1.87202988172)}
     
def main():
    '''User_based collaborative filtering
       Return result_ucf file'''
    
    root = 'gowalla_'
    folder = 'la'
    city = 'la'
    #test_num = gow_usernum_dic[city]
    test_num = 5
    print "=========\n" + root + folder, test_num, "ucf running \n========="

    root0 = 'C:\\Users\\I314279\\GQ\\data'
    read_write_dir =  os.path.join(root0, root + folder)
    train_read_path = os.path.join(read_write_dir, 'train_' + city + '.txt')
    test_read_path = os.path.join(read_write_dir,'test_' + city + '.txt')
    result_path = os.path.join(read_write_dir, 'result_ucf_g_' + city + '.txt')
    rec_list_path = os.path.join(read_write_dir, 'rec_list_ucf_g_' + city + '.txt')
    ucf_g(read_write_dir, train_read_path, test_read_path, result_path, rec_list_path, test_num, city)
    
    print "===" + root + folder + " ucf over===", test_num
    
    
if __name__ == '__main__':
    main()
        
