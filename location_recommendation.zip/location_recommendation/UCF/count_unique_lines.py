# -*- coding: utf-8 -*-
"""
Created on Fri Nov 07 20:34:12 2014

@author: guoqing
"""

read_write_dir = 'C:/Users/GuoQing/Desktop/data/foursquare_sg'
read_path = read_write_dir + '/foursquare_sg_ft_pro.txt'

read_fp = open(read_path, 'r')
lines_list = read_fp.readlines()
lines_list = list(set(lines_list))

print len(lines_list) 