# -*- coding: utf-8 -*-
"""
Created on Thu Mar 05 10:16:08 2015

@author: I314279
"""

from math import pi, sqrt, cos, sin, asin, log
import os

class user:
    '''this class is to save poi lat and lon of a user'''
    
    def __init__(self, uid):
        self.uid = uid
        self.lat_lon_list = []
        
    def add_lat_lon_toList(self, lat_lon):
        if lat_lon not in self.lat_lon_list:
            self.lat_lon_list.append(lat_lon)
        
    def get_lat_lon_list(self):
        return self.lat_lon_list 


def compute_geodist(lat_lon1, lat_lon2):
    lat1 = lat_lon1[0]; lon1 =lat_lon1[1]
    lat2 = lat_lon2[0]; lon2 =lat_lon2[1]
    rad_lat1 = lat1*pi/180.0
    rad_lat2 = lat2*pi/180.0
    phi = rad_lat1 - rad_lat2
    lambdaa = lon1*pi/180.0 - lon2*pi/180.0
    u = sin(phi/2.0)
    v = sin(lambdaa/2.0)
    s = 2*asin(sqrt(u * u + cos(rad_lat1) * cos(rad_lat2) * v * v))
    return s * 6378.137


def prep_reg_file(train_path, reg_write_path):
    '''this function is to prepare the file for regression'''
    
    user_obj_list = []
    # record the index of a user in user_obj_list
    user_index_dic = {}
    i = -1
    train_fp = open(train_path, 'r')
    line = train_fp.readline()
    while line != '':
        line = line.strip('\n')
        line_list = line.split(',')
        uid = line_list[0]
        lat = float(line_list[1])
        lon = float(line_list[2])
        #a new user come
        if uid not in user_index_dic:
            i += 1
            #set her index in user_index_dic
            user_index_dic[uid] = i
            # notice "userRec"
            user_obj = user(uid)
            #add the poi to poi_w_dic of a user
            user_obj.add_lat_lon_toList((lat, lon))
            #append her to the list
            user_obj_list.append(user_obj)
        #the user is already existing
        else:
            #get her index in the list
            user_index = user_index_dic[uid]
            user_obj = user_obj_list[user_index]
            #add the poi to her visited poi list
            user_obj.add_lat_lon_toList((lat, lon))
        line = train_fp.readline()
    train_fp.close()
    print "get all the users train records"  
    
    k = 0
    dist_num_dict = {}
    for user_obj in user_obj_list:
        k+=1
        print k
        lat_lon_list = user_obj.get_lat_lon_list()
        for i in range(0, len(lat_lon_list)-1):
            lat_lon1 = lat_lon_list[i]
            for j in range(i+1, len(lat_lon_list)):
                lat_lon2 = lat_lon_list[j]
                dist = round(compute_geodist(lat_lon1, lat_lon2),0)
                if dist not in dist_num_dict:
                    dist_num_dict[dist] = 1
                else:
                    dist_num_dict[dist] += 1
    print "get dist_num_dict"
    
    reg_write_fp = open(reg_write_path, 'w')
    for dist in dist_num_dict:
        try:
            one = '%.1f' % 1
            dist_num = '%.1f' % log(dist_num_dict[dist], 2)
            dist = '%.1f' % log(dist, 2)
            line = '\t'.join([one, dist, dist_num]) + '\n'
            reg_write_fp.write(line)
        except:
            continue
    reg_write_fp.close()
    print "get regression file"
        
    

def main():
    
    root = 'gowalla_'
    folder = 'sf'
    print "=========\n" + root + folder, "prepare regression running \n========="

    root0 = 'C:\\Users\\I314279\\GQ\\data'
    read_write_dir =  os.path.join(root0, root + folder)
    train_path = os.path.join(read_write_dir, 'train_'+folder+'.txt')
    reg_write_path = os.path.join(read_write_dir, 'reg_'+folder+'.txt')
    prep_reg_file(train_path, reg_write_path)
    
    print "=====finish preparing regression file====="
    
if __name__ == '__main__':
    main()