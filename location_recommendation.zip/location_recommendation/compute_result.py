# -*- coding: utf-8 -*-

import os

class user:
    '''This class is to desribe a user's profile and it's only 
        for gettingtrain and test set'''
    
    def __init__(self, uid=None):
        self.uid = uid
        self.rec_list = []
        self.test_list = []
    
    def set_rec_list(self, rec_list):
        self.rec_list = rec_list
    
    def get_rec_list(self):
        return self.rec_list
    
    def add_poi_to_test_list(self,poi):
        if poi not in self.test_list:
            self.test_list.append(poi)
    
    def get_test_list(self):
        return self.test_list


def compute_result(test_read_path, rec_list_path, result_path):
    
    # save recommendation list of each user
    user_index_dic = {}
    user_obj_list = []
    rec_fp = open(rec_list_path, 'r')
    line = rec_fp.readline()
    i = -1
    while line != '':
        line = line.strip('\n')
        line_list = line.split(',')
        uid = line_list[0]
        rec_list = line_list[1:]
        #a new user come
        if uid not in user_index_dic:
            i += 1
            #set her index in user_index_dic
            user_index_dic[uid] = i
            # notice "userRec"
            user_obj = user(uid)
            #add the poi to poi_w_dic of a user
            user_obj.set_rec_list(rec_list)
            #append her to the list
            user_obj_list.append(user_obj)
        line = rec_fp.readline()
    rec_fp.close()
    print "get the recommend list for all users"     
    
    # then get the poi test list of users
    test_fp = open(test_read_path, 'r')
    line = test_fp.readline()
    while line != '':
        line = line.strip('\n')
        line_list = line.split(',')
        uid = line_list[0]
        poi_id = line_list[3]
        # get the user object index in the user_index_dic
        user_index = user_index_dic[uid]
        # get the user object and add poi_id to test_list of the user
        user_obj_list[user_index].add_poi_to_test_list(poi_id)
        line = test_fp.readline()
    test_fp.close()
    print "get all users test records"    
    
    # compute precision and recall
    precision_sum = [0.0 for i in range(0, 11)]
    recall_sum = [0.0 for i in range(0, 11)] 
    test_zero_num = 0
    #for user_obj in user_obj_list:
    for i in range(0, test_num):
        user_obj = user_obj_list[i]
        precision = [0.0 for i in range(0, 11)]
        recall = [0.0 for i in range(0, 11)]
        user_rec_list = user_obj.get_rec_list()
        #print 'uid', user_obj.get_uid()
        #print "rec", user_rec_list
        user_test_set = set(user_obj.get_test_list())
        #print "test", user_test_set
        user_test_poi_num = len(user_test_set)
        if user_test_poi_num == 0.0: 
            test_zero_num += 1
            continue
        for j in range(0, 11):
            if j == 0:
                predict_num = 5
            else:
                predict_num = j * 10
            user_rec_set_j = set(user_rec_list[0:predict_num])
            #print user_rec_set_j
            hit_num =  float(len(user_rec_set_j.intersection(user_test_set)))
            #print user_rec_set_j.intersection(user_test_set)
            #print "hit_num", hit_num
            precision[j] = hit_num / (predict_num)
            #print 'precision', precision[j]
            recall[j] = hit_num / user_test_poi_num
            precision_sum[j] += precision[j]
            recall_sum[j] += recall[j]
            
    # save the result
    user_num = len(user_obj_list) - test_zero_num
    user_num  = test_num - test_zero_num + add_num
    result_fp = open(result_path, 'w')
    for j in range(0, 11):
        precision_average = precision_sum[j] / user_num
        #print precision_average
        recall_average = recall_sum[j] / user_num
        #print precision_average
        if j == 0:
            predict_num = 5
        else:
            predict_num = j*10
        line = str(predict_num) + '\t' + '%0.5f' % (precision_average) + '\t' + \
                '%0.5f' % (recall_average) + '\n'
        result_fp.write(line)
    result_fp.close()
  
# modify !!!
test_num = 2531
# foursquare2: la 554, ny 2885, sf: 806
# foursquare1: la 514, ny: 2310, sf: 725
# gowalla: la 1279, ny 2171, sf 2531
add_num = 0

def main():
    
    #root = 'foursquare_'
    root = 'gowalla_'
    folder = 'ny'
    city = 'ny'
    #algo = 'ucf_'
    #algo = 'lcf_'
    #algo = 'tspr_15_minus_'
    #algo = 'tspr_15_minus_kernel_product_'
    #algo = 'tspr_no_15_'
    #algo = 'personal_pr_'
    algo = 'kernel_geo_kernel_'
    
    read_write_dir = os.path.join('C:\Users\I314279\GQ\data', root + folder)
    
    test_read_path = os.path.join(read_write_dir, 'test_' + city + '.txt')
    result_path = os.path.join(read_write_dir, 'result_' + algo + city + '.txt')
    rec_list_path = os.path.join(read_write_dir, 'rec_list_' + algo + city + '.txt')
    compute_result(test_read_path, rec_list_path, result_path)
    
    print result_path
    print "=== save result ==="
    
    
if __name__ == '__main__':
    main()
    
    