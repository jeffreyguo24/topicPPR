# -*- coding: utf-8 -*-
"""
Created on Fri Oct 24 20:40:53 2014

@author: guoqing
"""

from foursquare import Foursquare

def test_map_category(lat, lon):
    foursquare1 = Foursquare(client_id = '42HTARZH24LD5GJTT1JJ1R0XG5FCS5JHNXKGSJB3GDBRI05L',
                             client_secret = u'KR0QWDQ2SKOFVXOTLXENIPOWFUCWGGB3UPDDBQ3AOFIYCWSS')
    foursquare2 = Foursquare(client_id = 'DTVS4L10HL3MEBRBLYYYI340BGJCZE2ZHCXX2DNCKG4YF353',
                             client_secret = 'YQ1LAWGFXNNQPZARHDMT43V5HM3QZX5XKR3FYL1CCDUF5N4L')
                             
    list_result =  foursquare1.venues.search(params={'ll':lat+','+lon,'limit':1,'radius':500})  
    list_result_venues = list_result['venues'][0]
    loc_id = list_result_venues['id']
    venue_details = foursquare2.venues(loc_id)
    #print venue_details
    category_num = len(venue_details['venue']['categories'])
    for i in range(0, category_num):
        print i, venue_details['venue']['categories'][i]['id'],\
        venue_details['venue']['categories'][i]['name']
    '''
    print "\ncategories", loc_categories
    #loc_types_string = ''
    category_num = len(loc_categories)
    print category_num
    line = ''
    for i in range(0, category_num):
        line += loc_categories[i]['name'] + '\t' + loc_categories[i]['id']
          
    print line
    '''
    
def main():
    #40.721294,-73.983994
    lat = str( 40.721294)
    lon = str(-73.983994)
    test_map_category(lat, lon)
    
if __name__ == '__main__':
    main()
    


'''
#将第一个结果放到一个list中
    
    #categories1 = list_result_venues.categories()
    #print categories1
    print list_result_venues
    loc_city = list_result_venues['location']['city']
    #loc_state = list_result_venues['location']['state']
    #loc_country = list_result_venues['location']['country']
    #loc_name = list_result_venues['name']
    loc_categories = list_result_venues['categories']
'''